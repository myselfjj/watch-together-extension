const WS_SERVER_HTTP = 'https://watch-together-extension.onrender.com';
const WAKE_MESSAGES = [
  'Connecting to server...',
  'Server is waking up, hang tight ☕',
  'Still warming up — free servers take a bit...',
  'Almost there...',
  'Render free tier doing its thing ⏳',
  'Nearly ready, just a moment...',
  'Hang on, almost connected...',
  'One more moment...',
];

let currentRoom = null;
let currentUsername = null;
let wakeCheckInterval = null;
let wakeMessageInterval = null;
let wakeTimeout = null;
let pendingAction = null; // { type: 'CREATE_ROOM'|'JOIN_ROOM', roomId, username }

// DOM refs
const initialView = document.getElementById('initialView');
const roomView = document.getElementById('roomView');
const usernameInput = document.getElementById('usernameInput');
const roomIdInput = document.getElementById('roomIdInput');
const createRoomBtn = document.getElementById('createRoomBtn');
const joinRoomBtn = document.getElementById('joinRoomBtn');
const currentRoomId = document.getElementById('currentRoomId');
const participantCount = document.getElementById('participantCount');
const copyRoomIdBtn = document.getElementById('copyRoomIdBtn');
const leaveRoomBtn = document.getElementById('leaveRoomBtn');
const successMsg = document.getElementById('successMsg');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const loadingOverlay = document.getElementById('loadingOverlay');
const loadingMsg = document.getElementById('loadingMsg');
const retryBtn = document.getElementById('retryBtn');

document.addEventListener('DOMContentLoaded', async () => {
  const result = await chrome.storage.local.get(['username', 'roomId']);
  if (result.username) {
    usernameInput.value = result.username;
    currentUsername = result.username;
  }

  if (result.roomId) {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'PING' }, (response) => {
          if (chrome.runtime.lastError) {
            chrome.storage.local.remove(['roomId']);
            return;
          }
          // Only restore the room view if the content script confirms it's in
          // THIS room (matching id). Avoids showing a stale room from storage.
          if (response?.inRoom && response?.roomId === result.roomId) {
            currentRoom = result.roomId;
            showRoomView();
          } else {
            chrome.storage.local.remove(['roomId']);
          }
        });
      }
    } catch {
      chrome.storage.local.remove(['roomId']);
    }
  }

  usernameInput.addEventListener('input', () => clearError('username'));
  roomIdInput.addEventListener('input', () => clearError('roomId'));
  checkPageStatus();
});

// -- Create room --------------------------------------------------------------
createRoomBtn.addEventListener('click', async () => {
  const username = usernameInput.value.trim();
  clearError('username');
  if (!username || username.length < 2) {
    showInlineError('username', 'Please enter your name (at least 2 characters)');
    return;
  }
  currentUsername = username;
  await chrome.storage.local.set({ username });

  const roomId = generateRoomId();
  currentRoom = roomId;
  await chrome.storage.local.set({ roomId });

  pendingAction = { type: 'CREATE_ROOM', roomId, username };
  startWakeUpSequence();
});

// -- Join room ----------------------------------------------------------------
joinRoomBtn.addEventListener('click', async () => {
  const username = usernameInput.value.trim();
  const roomId = roomIdInput.value.trim().toUpperCase();
  clearError('username');
  clearError('roomId');

  if (!username || username.length < 2) {
    showInlineError('username', 'Please enter your name (at least 2 characters)');
    return;
  }
  if (!roomId) {
    showInlineError('roomId', 'Please enter a room ID');
    return;
  }

  currentUsername = username;
  currentRoom = roomId;
  await chrome.storage.local.set({ username, roomId });

  pendingAction = { type: 'JOIN_ROOM', roomId, username };
  startWakeUpSequence();
});

// -- Server wake-up sequence --------------------------------------------------
function startWakeUpSequence() {
  showLoadingOverlay();
  let msgIndex = 0;
  let elapsed = 0;

  // Cycle messages every 3s
  wakeMessageInterval = setInterval(() => {
    msgIndex = (msgIndex + 1) % WAKE_MESSAGES.length;
    loadingMsg.textContent = WAKE_MESSAGES[msgIndex];
  }, 3000);

  // Poll health endpoint every 2s
  wakeCheckInterval = setInterval(async () => {
    elapsed += 2000;
    if (elapsed >= 60000) {
      clearWakeIntervals();
      loadingMsg.textContent = 'Server took too long to respond.';
      retryBtn.classList.remove('hidden');
      setStatus('error', 'Unreachable');
      return;
    }
    const ok = await pingServer();
    if (ok) {
      clearWakeIntervals();
      hideLoadingOverlay();
      dispatchPendingAction();
    }
  }, 2000);

  // Also try immediately
  pingServer().then(ok => {
    if (ok) {
      clearWakeIntervals();
      hideLoadingOverlay();
      dispatchPendingAction();
    }
  });
}

async function pingServer() {
  return new Promise((resolve) => {
    const wsUrl = WS_SERVER_HTTP.replace(/^http/, 'ws');
    let ws;
    const timer = setTimeout(() => {
      try { ws.close(); } catch {}
      resolve(false);
    }, 4000);
    try {
      ws = new WebSocket(wsUrl);
      ws.onopen = () => {
        clearTimeout(timer);
        ws.close();
        resolve(true);
      };
      ws.onerror = () => {
        clearTimeout(timer);
        resolve(false);
      };
    } catch {
      clearTimeout(timer);
      resolve(false);
    }
  });
}

function clearWakeIntervals() {
  clearInterval(wakeCheckInterval);
  clearInterval(wakeMessageInterval);
  clearTimeout(wakeTimeout);
}

function dispatchPendingAction() {
  if (!pendingAction) return;
  sendToContentScript(pendingAction);
  showRoomView();
  showSuccess(pendingAction.type === 'CREATE_ROOM' ? 'Room created!' : 'Joined room!');
  pendingAction = null;
}

retryBtn.addEventListener('click', () => {
  retryBtn.classList.add('hidden');
  loadingMsg.textContent = WAKE_MESSAGES[0];
  startWakeUpSequence();
});

// -- Other controls -----------------------------------------------------------
copyRoomIdBtn.addEventListener('click', () => {
  navigator.clipboard.writeText(currentRoom);
  copyRoomIdBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Copied!`;
  setTimeout(() => {
    copyRoomIdBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copy`;
  }, 2000);
});

// Sync Now lives in the in-page panel header now (not the popup).

leaveRoomBtn.addEventListener('click', async () => {
  sendToContentScript({ type: 'LEAVE_ROOM' });
  await chrome.storage.local.remove(['roomId']);
  currentRoom = null;
  showInitialView();
  roomIdInput.value = '';
});

// -- Message listener ---------------------------------------------------------
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'PARTICIPANT_COUNT') {
    participantCount.textContent = message.count;
  } else if (message.type === 'CONNECTION_STATUS') {
    if (message.connected) {
      setStatus('connected', 'Connected');
    } else {
      setStatus('', 'Disconnected');
    }
  } else if (message.type === 'ROOM_ERROR') {
    // Room not found — reset popup to initial view and show error
    currentRoom = null;
    chrome.storage.local.remove(['roomId']);
    showInitialView();
    showInlineError('roomId', message.message || 'Room not found.');
    setStatus('error', 'Not connected');
  } else if (message.type === 'LEFT_ROOM') {
    // User left via the in-page panel — return the popup to the initial view.
    currentRoom = null;
    chrome.storage.local.remove(['roomId']);
    showInitialView();
    setStatus('', 'Not connected');
  }
});

// -- View helpers -------------------------------------------------------------
function showRoomView() {
  initialView.classList.add('hidden');
  roomView.classList.remove('hidden');
  currentRoomId.textContent = currentRoom;
  sendToContentScript({ type: 'GET_PARTICIPANT_COUNT' });
  checkPageStatus();
}

function showInitialView() {
  roomView.classList.add('hidden');
  initialView.classList.remove('hidden');
}

function showLoadingOverlay() {
  loadingOverlay.classList.add('show');
  loadingMsg.textContent = WAKE_MESSAGES[0];
  retryBtn.classList.add('hidden');
  setStatus('waking', 'Waking up...');
}

function hideLoadingOverlay() {
  loadingOverlay.classList.remove('show');
  setStatus('connected', 'Connected');
}

function setStatus(state, text) {
  statusDot.className = 'status-dot' + (state ? ` ${state}` : '');
  statusText.textContent = text;
}

function showInlineError(field, msg) {
  const input = document.getElementById(`${field}Input`);
  const errEl = document.getElementById(`${field}Error`);
  input.classList.add('error');
  errEl.textContent = msg;
  errEl.classList.add('show');
  input.focus();
}

function clearError(field) {
  const input = document.getElementById(`${field}Input`);
  const errEl = document.getElementById(`${field}Error`);
  input.classList.remove('error');
  errEl.classList.remove('show');
  errEl.textContent = '';
}

function showSuccess(msg) {
  successMsg.textContent = msg;
  successMsg.classList.add('show');
  setTimeout(() => successMsg.classList.remove('show'), 3000);
}

async function checkPageStatus() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs[0]) { setStatus('', 'No tab'); return; }
    const url = tabs[0].url || '';
    const supported = ['youtube.com','netflix.com','disneyplus.com','primevideo.com',
      'hotstar.com','hulu.com','hbomax.com','zee5.com','sonyliv.com','voot.com',
      'vidrock.net','vidrock.ru','videasy.net','videasy.to'];
    if (!supported.some(s => url.includes(s))) {
      setStatus('', 'Open a video site');
      return;
    }
    chrome.tabs.sendMessage(tabs[0].id, { type: 'PING' }, (response) => {
      if (chrome.runtime.lastError) { setStatus('', 'Not connected'); return; }
      setStatus(response?.connected ? 'connected' : '', response?.connected ? 'Connected' : 'Not connected');
    });
  } catch {
    setStatus('', 'Error');
  }
  setTimeout(checkPageStatus, 5000);
}

async function sendToContentScript(message) {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, message, (response) => {
        if (chrome.runtime.lastError) {
          if (message.type === 'CREATE_ROOM' || message.type === 'JOIN_ROOM') {
            showInlineError('username', 'Open a video page first (YouTube, Netflix, VidRock, Videasy, etc.)');
          }
        }
      });
    }
  } catch (e) {
    console.error('sendToContentScript error:', e);
  }
}

function generateRoomId() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  return Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}
