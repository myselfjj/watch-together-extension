// Injected script for deeper video player control
// This script runs in the page context for platforms that need it

(function() {
  'use strict';

  // Enhanced video control for platforms with custom players
  const platforms = {
    netflix: {
      getPlayer: () => {
        const videoPlayer = netflix?.appContext?.state?.playerApp?.getAPI()?.videoPlayer;
        const sessionId = videoPlayer?.getAllPlayerSessionIds()?.[0];
        return sessionId ? videoPlayer.getVideoPlayerBySessionId(sessionId) : null;
      },
      play: (player) => player?.play(),
      pause: (player) => player?.pause(),
      seek: (player, time) => player?.seek(time * 1000),
      getCurrentTime: (player) => player?.getCurrentTime() / 1000,
      setPlaybackRate: (player, rate) => player?.setPlaybackRate(rate)
    },
    youtube: {
      getPlayer: () => document.querySelector('video'),
      play: (player) => player?.play(),
      pause: (player) => player?.pause(),
      seek: (player, time) => { if (player) player.currentTime = time; },
      getCurrentTime: (player) => player?.currentTime,
      setPlaybackRate: (player, rate) => { if (player) player.playbackRate = rate; }
    }
  };

  // Detect platform
  function detectPlatform() {
    const hostname = window.location.hostname;
    if (hostname.includes('netflix')) return 'netflix';
    if (hostname.includes('youtube')) return 'youtube';
    return 'default';
  }

  // Expose controls to content script
  window.watchTogetherControls = {
    platform: detectPlatform(),
    getPlayer: function() {
      const platform = platforms[this.platform] || platforms.youtube;
      return platform.getPlayer();
    },
    play: function() {
      const platform = platforms[this.platform] || platforms.youtube;
      const player = platform.getPlayer();
      if (player) platform.play(player);
    },
    pause: function() {
      const platform = platforms[this.platform] || platforms.youtube;
      const player = platform.getPlayer();
      if (player) platform.pause(player);
    },
    seek: function(time) {
      const platform = platforms[this.platform] || platforms.youtube;
      const player = platform.getPlayer();
      if (player) platform.seek(player, time);
    },
    getCurrentTime: function() {
      const platform = platforms[this.platform] || platforms.youtube;
      const player = platform.getPlayer();
      return player ? platform.getCurrentTime(player) : 0;
    },
    setPlaybackRate: function(rate) {
      const platform = platforms[this.platform] || platforms.youtube;
      const player = platform.getPlayer();
      if (player) platform.setPlaybackRate(player, rate);
    }
  };

  console.log('WatchTogether: Enhanced controls injected');
})();
