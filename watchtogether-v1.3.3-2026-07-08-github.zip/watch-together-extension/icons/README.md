# Icon Files

This folder contains the icon files for the WatchTogether extension.

## Quick Setup

### Option 1: Generate via HTML (Easiest)
1. Open `generate-icons.html` in your browser
2. Click "Download All Icons"
3. Save the three PNG files here

### Option 2: Create Manually
Create three PNG files with these specifications:

#### icon16.png (16x16 pixels)
- Purple gradient background (#667eea to #764ba2)
- White play triangle in center
- Rounded corners

#### icon48.png (48x48 pixels)
- Same design as 16x16
- More detail visible
- Film strip perforations in corners

#### icon128.png (128x128 pixels)
- Same design as 48x48
- High resolution for Chrome Web Store

### Option 3: Use Design Tool
Use Figma, Photoshop, or any image editor:
1. Create 128x128 canvas
2. Add purple gradient background (135° angle)
   - Start: #667eea
   - End: #764ba2
3. Add white play triangle in center
4. Add rounded corners (20% radius)
5. Export as PNG
6. Resize to 48x48 and 16x16

## Required Files

All three files must be present for the extension to work:
- ✅ icon16.png - Toolbar icon
- ✅ icon48.png - Extension management page
- ✅ icon128.png - Chrome Web Store listing

## Verification

After creating icons, check:
1. All three files exist in this folder
2. Files are PNG format
3. Files have correct dimensions (16x16, 48x48, 128x128)
4. Files are under 50KB each
5. Extension loads without icon errors in chrome://extensions/

## Troubleshooting

**Extension shows generic icon:**
- Make sure all three PNG files exist
- Check file names are exactly: icon16.png, icon48.png, icon128.png
- Verify files aren't corrupted (can open in image viewer)
- Reload extension in Chrome

**Icons look blurry:**
- Ensure PNG files are correct size (not stretched)
- Use the HTML generator for best quality
- Don't use JPG format

---

**Don't forget:** Generate icons before loading the extension!
