// Content script for WatchTogether extension
// This script runs on video streaming platforms and syncs playback

let ws = null;
let roomId = null;
let username = null;
let isHost = false;
let syncInterval = null;
let videoElement = null;
let isSyncing = false;
let lastSyncTime = 0;
let sidePanelInjected = false;
let myUserId = null;
let localStream = null;
let peerConnections = new Map(); // Map of userId -> RTCPeerConnection
let isMuted = true;
let participants = [];
let audioContext = null;
let localAnalyser = null;
let remoteAnalysers = new Map(); // Map of userId -> analyser

let iceServersCache = null; // cached for session duration
let iceServersFetchedAt = 0; // when the TURN creds were last fetched (TTL)
let localVideoStream = null; // separate stream with video track
let isCameraOn = false;
const remoteVideoStreams = new Map(); // userId -> MediaStream (latest received stream)
const remoteCameraOn = new Map();    // userId -> boolean (camera state per peer)
const remoteMicMuted = new Map();    // userId -> boolean (mic muted state per peer, survives list rebuilds)
const pendingCandidates = new Map(); // userId -> [RTCIceCandidate] buffered until remoteDescription is set
const creatingPeers = new Set();     // userIds with an in-flight createPeerConnection (dedupe guard)

// Per-page-load identity. Lets the server recognise THIS tab reconnecting (new
// socket = new server userId each time) and evict only this tab's stale socket.
const SESSION_ID = (self.crypto && self.crypto.randomUUID)
  ? self.crypto.randomUUID()
  : String(Date.now()) + Math.random().toString(36).slice(2);

// Session lifecycle guards
let reconnectTimer = null;  // pending auto-reconnect setTimeout handle
let voiceEpoch = 0;         // bumped on every teardown; stale async getUserMedia checks this
let hasJoinedRoom = false;  // true once we've joined at least once → reconnects skip the stale post-join sync
let syncResetTimer = null;  // cancellable isSyncing reset
let seekDebounceTimer = null; // trailing-edge seek debounce

const CRED_TTL_MS = 50 * 60 * 1000; // TURN creds are time-limited; refetch after 50min
async function getTurnCredentials() {
  // Reuse cached creds only while still fresh. STUN-only fallback is NOT cached
  // long-term (fetchedAt left at 0) so we keep retrying for real TURN servers.
  if (iceServersCache && iceServersFetchedAt && (Date.now() - iceServersFetchedAt < CRED_TTL_MS)) {
    return iceServersCache;
  }
  try {
    const res = await fetch(
      'https://watchtogetherextension.metered.live/api/v1/turn/credentials?apiKey=bc162b882e312e0760fb37f614979684e511',
      { signal: AbortSignal.timeout(5000) }
    );
    const servers = await res.json();
    iceServersCache = [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      ...servers
    ];
    iceServersFetchedAt = Date.now();
    console.log('WatchTogether: TURN credentials fetched', iceServersCache.length, 'servers');
  } catch {
    console.log('WatchTogether: TURN fetch failed, falling back to STUN only');
    iceServersCache = [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
    ];
    iceServersFetchedAt = 0; // do not treat STUN-only as a satisfied fetch
  }
  return iceServersCache;
}

const SYNC_THRESHOLD = 2; // seconds
const SYNC_INTERVAL = 2000; // ms
// Production server URL
// For local testing: 'ws://localhost:3000'
// For production: use deployed server URL
const WS_SERVER = 'wss://watch-together-extension.onrender.com';

// Platform-specific video selectors
const VIDEO_SELECTORS = {
  youtube: 'video',
  netflix: 'video',
  disneyplus: 'video',
  primevideo: 'video',
  hotstar: 'video',
  hulu: 'video',
  hbomax: 'video',
  zee5: 'video',
  sonyliv: 'video',
  voot: 'video',
  vidrock: 'video',
  videasy: 'video'
};

// Initialize
function init() {
  console.log('WatchTogether: Content script loaded');
  detectVideoElement();
  setupMessageListener();
  // HTTP ping every 4 minutes as extra keep-alive (UptimeRobot also pings every 5 min)
  setInterval(() => {
    if (roomId) fetch('https://watch-together-extension.onrender.com/health').catch(() => {});
  }, 4 * 60 * 1000);
}

// Detect video element on the page
function detectVideoElement() {
  const currentPlatform = detectPlatform();
  const selector = VIDEO_SELECTORS[currentPlatform] || 'video';
  
  // Wait for video element to appear
  const observer = new MutationObserver(() => {
    const video = document.querySelector(selector);
    if (video && !videoElement) {
      videoElement = video;
      console.log('WatchTogether: Video element detected', videoElement);
      setupVideoListeners();
      // A video that appears AFTER we're already in a room (e.g. Videasy creates it
      // only on first play, or a late joiner) must catch up to the room position.
      if (roomId) requestSync();
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Try to find video immediately
  const video = document.querySelector(selector);
  if (video) {
    videoElement = video;
    setupVideoListeners();
    if (roomId) requestSync();
  }
}

// Detect current platform
function detectPlatform() {
  const hostname = window.location.hostname;
  if (hostname.includes('youtube')) return 'youtube';
  if (hostname.includes('netflix')) return 'netflix';
  if (hostname.includes('disneyplus')) return 'disneyplus';
  if (hostname.includes('primevideo')) return 'primevideo';
  if (hostname.includes('hotstar')) return 'hotstar';
  if (hostname.includes('hulu')) return 'hulu';
  if (hostname.includes('hbomax')) return 'hbomax';
  if (hostname.includes('zee5')) return 'zee5';
  if (hostname.includes('sonyliv')) return 'sonyliv';
  if (hostname.includes('voot')) return 'voot';
  if (hostname.includes('vidrock')) return 'vidrock';
  if (hostname.includes('videasy')) return 'videasy';
  return 'unknown';
}

// Setup video event listeners
function setupVideoListeners() {
  if (!videoElement) return;

  videoElement.addEventListener('play', handlePlay);
  videoElement.addEventListener('pause', handlePause);
  videoElement.addEventListener('seeked', handleSeeked);
  videoElement.addEventListener('ratechange', handleRateChange);

  console.log('WatchTogether: Video listeners attached');
}

// Handle play event
function handlePlay() {
  if (isSyncing) return;

  refreshSyncChipLocal(); // our own action isn't echoed back, so update our chip now
  if (ws && ws.readyState === WebSocket.OPEN) {
    sendSyncMessage({
      type: 'play',
      time: videoElement.currentTime,
      timestamp: Date.now()
    });
  }
}

// Handle pause event
function handlePause() {
  if (isSyncing) return;

  refreshSyncChipLocal();
  if (ws && ws.readyState === WebSocket.OPEN) {
    sendSyncMessage({
      type: 'pause',
      time: videoElement.currentTime,
      timestamp: Date.now()
    });
  }
}

// Handle seek event — trailing-edge debounce so dragging the scrubber sends ONE
// seek at the final position (leading-edge dropped intermediate seeks → desync).
function handleSeeked() {
  if (isSyncing) return; // a remotely-applied seek must not echo back
  if (seekDebounceTimer) clearTimeout(seekDebounceTimer);
  seekDebounceTimer = setTimeout(() => {
    seekDebounceTimer = null;
    if (isSyncing) return; // re-check: a sync may have landed during the wait
    if (videoElement && ws && ws.readyState === WebSocket.OPEN) {
      sendSyncMessage({ type: 'seek', time: videoElement.currentTime, timestamp: Date.now() });
    }
    lastSyncTime = Date.now();
  }, 300);
}

// Handle playback rate change
function handleRateChange() {
  if (isSyncing) return;
  
  if (ws && ws.readyState === WebSocket.OPEN) {
    sendSyncMessage({
      type: 'ratechange',
      rate: videoElement.playbackRate,
      time: videoElement.currentTime,
      timestamp: Date.now()
    });
  }
}

// Is the mic stream actually usable? Rejects ended AND OS-muted/zombie tracks so
// a stream object that exists but produces no audio is treated as dead.
function isStreamAlive(stream) {
  if (!stream) return false;
  const audio = stream.getAudioTracks();
  return audio.length > 0 && audio.every(t => t.readyState === 'live' && !t.muted);
}

// Fully tear down the current session. Single choke-point so every teardown caller
// (CREATE/JOIN, LEAVE, ROOM_NOT_FOUND, panel leave) resets the SAME state — no leaks.
function resetSession() {
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  if (ws) {
    // Tell the server we're intentionally leaving so peers see "left" instantly
    // (no deferred-leave grace), then detach handlers so no auto-reconnect fires.
    try { if (ws.readyState === WebSocket.OPEN && roomId) ws.send(JSON.stringify({ type: 'leave', roomId })); } catch {}
    try { ws.onopen = ws.onmessage = ws.onerror = ws.onclose = null; ws.close(); } catch {}
    ws = null;
  }
  stopSyncInterval();
  cleanupVoiceChat(); // bumps voiceEpoch, resets sync flags, clears all per-peer maps
  roomId = null;
  username = null;
  isHost = false;
  hasJoinedRoom = false;
}

// Drop a dead/closed peer connection and all UI/state keyed to that userId.
function removePeer(userId) {
  const pc = peerConnections.get(userId);
  if (pc) { stopSilentTracks(pc); try { pc.close(); } catch {} peerConnections.delete(userId); }
  creatingPeers.delete(userId);
  pendingCandidates.delete(userId);
  remoteVideoStreams.delete(userId);
  remoteCameraOn.delete(userId);
  remoteMicMuted.delete(userId);
  stopVoiceActivityDetection(userId);
  const audio = document.getElementById(`wt-audio-${userId}`);
  if (audio) audio.remove();
  const tile = document.getElementById(`wt-tile-${userId}`);
  if (tile) tile.remove();
  applyCinemaMode(); // a camera may have just left
}

// Tear down all peer connections + their audio elements (used on reconnect, where
// every remote peer will reappear under a fresh server-assigned userId).
function teardownPeerConnections() {
  peerConnections.forEach(pc => { stopSilentTracks(pc); try { pc.close(); } catch {} });
  peerConnections.clear();
  creatingPeers.clear();
  pendingCandidates.clear();
  document.querySelectorAll('audio[id^="wt-audio-"]').forEach(a => a.remove());
  remoteAnalysers.clear();
}

// Connect to WebSocket server
function connectWebSocket(room, user, host = false, retryCount = 0) {
  roomId = room;
  username = user;
  isHost = host;

  const MAX_RETRIES = 20;
  let didOpen = false;

  // Cancel any pending reconnect and fully detach the previous socket so we never
  // run two overlapping WebSockets (a prime cause of duplicate joins / spam).
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  if (ws) {
    try { ws.onopen = ws.onmessage = ws.onerror = ws.onclose = null; ws.close(); } catch {}
    ws = null;
  }

  ws = new WebSocket(WS_SERVER);
  const socket = ws; // capture for identity checks inside async callbacks

  // Skip the FIRST non-drift sync on a reconnect (we've joined before) to avoid a
  // seek-back; first-ever join does NOT skip so a fresh joiner catches up.
  let skipNextSync = hasJoinedRoom;

  ws.onopen = () => {
    if (ws !== socket) return; // superseded by a newer connect
    didOpen = true;
    console.log('WatchTogether: Connected to sync server');

    ws.send(JSON.stringify({ type: 'join', roomId, username, create: isHost, sessionId: SESSION_ID }));
    notifyPopup({ type: 'CONNECTION_STATUS', connected: true });
    startSyncInterval();
    getTurnCredentials().catch(() => {}); // warm the ICE cache before peers connect

    // Re-evaluate liveness NOW (not at function entry) — the socket open gap can be
    // seconds long, during which the mic may have died.
    const reconnectLive = isStreamAlive(localStream);
    teardownPeerConnections(); // peers reappear with new ids; rebuild cleanly either way

    if (!reconnectLive) {
      // Fresh init (first connect, or mic died during the gap)
      if (localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; }
      initVoiceChat();
    } else {
      console.log('WatchTogether: Reconnected — reusing live mic stream');
      // Re-announce mic now; video-on is re-announced AFTER setupPeerConnections
      // (in the participants handler) so peers' PCs exist to receive it.
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'mic-status', roomId, muted: isMuted }));
      }
    }
  };

  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (data.type === 'pong') return;
      // 'drift' corrections must never be skipped — they are the re-sync mechanism.
      if (data.type === 'sync' && data.action !== 'drift' && skipNextSync) {
        skipNextSync = false;
        console.log('WatchTogether: Skipping post-reconnect sync to avoid seek-back');
        return;
      }
      handleSyncMessage(data);
    } catch (error) {
      console.error('WatchTogether: Error parsing message', error);
    }
  };

  ws.onerror = () => {
    // Suppress — onclose fires next and handles retry
  };

  ws.onclose = (event) => {
    if (ws === socket) ws = null;
    notifyPopup({ type: 'CONNECTION_STATUS', connected: false });
    stopSyncInterval();

    if (!roomId) return; // user left intentionally
    if (event && event.code === 4000) {
      // Evicted by a newer session (this same tab reconnected elsewhere) — do NOT
      // auto-reconnect or we'd fight the new socket.
      console.log('WatchTogether: Evicted by a newer session — not reconnecting');
      return;
    }

    const schedule = (delay, nextRetry) => {
      reconnectTimer = setTimeout(() => {
        reconnectTimer = null;
        if (!roomId) return; // left during the wait
        connectWebSocket(roomId, username, isHost, nextRetry);
      }, delay);
    };

    if (!didOpen && retryCount < MAX_RETRIES) {
      const delay = Math.min(3000 + retryCount * 500, 8000);
      console.log(`WatchTogether: Retrying connection (${retryCount + 1}/${MAX_RETRIES}) in ${delay}ms`);
      schedule(delay, retryCount + 1);
    } else if (didOpen) {
      console.log('WatchTogether: Lost connection, reconnecting in 3s...');
      schedule(3000, 0);
    } else {
      console.warn('WatchTogether: Server unreachable after max retries');
      // Keep trying slowly so a cold/free-tier server eventually reconnects.
      schedule(30000, 0);
    }
  };
}

// Format seconds → m:ss or h:mm:ss for attribution toasts.
function formatTime(s) {
  s = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  const mm = h > 0 ? String(m).padStart(2, '0') : String(m);
  return (h > 0 ? h + ':' : '') + mm + ':' + String(sec).padStart(2, '0');
}

// "Jayesh paused" / "Munna jumped to 1:23:45"
function showSyncAttribution(data) {
  const who = data.username;
  if (!who) return;
  let msg;
  if (data.action === 'play') msg = `${who} resumed playback`;
  else if (data.action === 'pause') msg = `${who} paused`;
  else if (data.action === 'seek') msg = `${who} jumped to ${formatTime(data.time)}`;
  else return;
  showAttributionToast(msg);
}

// Handle sync messages from server
function handleSyncMessage(data) {
  switch (data.type) {
    case 'sync':
      if (data.action === 'drift') {
        updateSyncChip(data.time, false);
        if (videoElement) applySyncState(data);
      } else {
        showSyncAttribution(data); // no-op when there's no username (join/auto-pause/drift)
        if (videoElement) applySyncState(data);
        if (typeof data.time === 'number') updateSyncChip(data.time, data.action === 'pause' || data.paused === true);
      }
      break;

    case 'reaction':
      spawnReaction(data.emoji);
      break;
    
    case 'chat':
      notifyPopup({
        type: 'CHAT_MESSAGE',
        username: data.username,
        message: data.message
      });
      updateSidePanel('chat', {
        username: data.username,
        message: data.message
      });
      break;
    
    case 'participants': {
      // Count is always authoritative. The LIST is only overwritten when present —
      // a count-only message (legacy/edge) must never blank everyone's UI/peers.
      const hasList = Array.isArray(data.list);
      const count = (typeof data.count === 'number') ? data.count : (hasList ? data.list.length : participants.length);

      notifyPopup({ type: 'PARTICIPANT_COUNT', count });
      updateSidePanel('room-info', {
        roomId: roomId,
        participants: count,
        connected: ws && ws.readyState === WebSocket.OPEN
      });

      if (hasList) {
        participants = data.list;
        updateSidePanel('participants-list', { participants });

        // Sweep ALL per-peer state for ids no longer present (tiles, audio, PCs, maps).
        const activeIds = new Set(participants.map(p => p.userId));
        if (myUserId) activeIds.add(myUserId);
        // Snapshot keys first — removePeer() mutates the Map.
        Array.from(peerConnections.keys()).forEach(uid => { if (!activeIds.has(uid)) removePeer(uid); });
        if (sidePanelInjected) {
          document.querySelectorAll('[id^="wt-tile-"]').forEach(tile => {
            const tileUserId = tile.id.replace('wt-tile-', '');
            if (!activeIds.has(tileUserId)) tile.remove();
          });
        }

        // Build/refresh peer connections, THEN announce mic + camera so peers' PCs
        // already exist to receive the video-on (otherwise late video is missed).
        if (localStream && myUserId) {
          setupPeerConnections().then(() => {
            if (ws && ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'mic-status', roomId, muted: isMuted }));
              if (isCameraOn) ws.send(JSON.stringify({ type: 'video-on', roomId }));
            }
          });
        }
        if (sidePanelInjected) updateAllVideoTiles();
      }
      break;
    }
    
    case 'joined':
      notifyPopup({
        type: 'CHAT_MESSAGE',
        username: 'System',
        message: `${data.username} joined the room`
      });
      updateSidePanel('system', {
        message: `${data.username} joined the room`
      });
      // If our camera is on, announce it so the new joiner can show our video tile
      if (isCameraOn && ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'video-on', roomId }));
      }
      break;
    
    case 'left': {
      // A reconnect-eviction still needs full cleanup but must NOT show a misleading
      // "<name> left the room" message (the same person is rejoining).
      if (data.reason !== 'reconnect') {
        updateSidePanel('system', { message: `${data.username} left the room` });
        notifyPopup({ type: 'CHAT_MESSAGE', username: 'System', message: `${data.username} left the room` });
      }
      // Update the list immediately for instant UI (a fresh 'participants' follows).
      participants = participants.filter(p => p.userId !== data.userId);
      notifyPopup({ type: 'PARTICIPANT_COUNT', count: participants.length });
      updateSidePanel('room-info', { roomId, participants: participants.length, connected: true });
      updateSidePanel('participants-list', { participants });
      if (data.userId) removePeer(data.userId); // closes PC, drops audio/tile/maps
      break;
    }
    
    case 'webrtc-offer':
      handleWebRTCOffer(data.fromUserId, data.offer);
      break;
    
    case 'webrtc-answer':
      handleWebRTCAnswer(data.fromUserId, data.answer);
      break;
    
    case 'webrtc-ice-candidate':
      handleWebRTCIceCandidate(data.fromUserId, data.candidate);
      break;
    
    case 'error':
      if (data.code === 'ROOM_NOT_FOUND') {
        // Full, consistent teardown (cancels reconnect timer, nulls onclose, etc.)
        resetSession();
        hideSidePanel();
        notifyPopup({ type: 'ROOM_ERROR', message: data.message });
      }
      break;

    case 'joined-room':
      myUserId = data.userId;
      hasJoinedRoom = true; // every subsequent (re)connect now skips the stale post-join sync
      console.log('WatchTogether: My user ID is', myUserId);
      // If voice already initialized and participants list received, setup now
      if (localStream && participants.length > 0) {
        setupPeerConnections();
      }
      break;

    case 'mic-status-update':
      remoteMicMuted.set(data.userId, data.muted); // cache so list rebuilds keep the icon
      handleMicStatusUpdate(data.userId, data.muted);
      break;

    case 'video-on': {
      if (!data.userId) break;
      const p = participants.find(p => p.userId === data.userId);
      const name = p?.username || data.userId;
      remoteCameraOn.set(data.userId, true);
      const stream = remoteVideoStreams.get(data.userId) || null;
      console.log('WatchTogether: video-on', name, '| stream:', !!stream);
      updateVideoTile(data.userId, name, stream, false);
      if (stream) waitForVideoData(data.userId, name);
      applyCinemaMode();
      break;
    }
    case 'video-off': {
      if (!data.userId) break;
      const p = participants.find(p => p.userId === data.userId);
      const name = p?.username || data.userId;
      remoteCameraOn.set(data.userId, false);
      // Keep remoteVideoStreams entry — the transceiver stream stays valid with the silent track
      updateVideoTile(data.userId, name, null, false);
      applyCinemaMode();
      break;
    }
  }
}

// Clear the sync mutex and any pending timers (used on teardown). Clearing the
// seek debounce here prevents a stale scrub from the old room firing into the new one.
function resetSyncState() {
  if (syncResetTimer) { clearTimeout(syncResetTimer); syncResetTimer = null; }
  if (seekDebounceTimer) { clearTimeout(seekDebounceTimer); seekDebounceTimer = null; }
  isSyncing = false;
  lastSyncTime = 0;
}

// Apply sync state to video. Wrapped in try/finally so the isSyncing mutex can
// NEVER strand true (a stranded mutex silently kills all local play/pause/seek).
function applySyncState(data) {
  if (!videoElement) return;

  const targetTime = (typeof data.time === 'number' && isFinite(data.time)) ? data.time : null;
  const isDrift = data.action === 'drift';

  // For periodic drift corrections, only act when actually playing and the gap is
  // real — otherwise skip entirely (don't even take the mutex) to avoid suppressing
  // the user's own controls every few seconds.
  if (isDrift) {
    if (targetTime === null || videoElement.paused) return;
    if (Math.abs(videoElement.currentTime - targetTime) <= SYNC_THRESHOLD) return;
  }

  isSyncing = true;
  try {
    if (targetTime !== null && Math.abs(videoElement.currentTime - targetTime) > SYNC_THRESHOLD) {
      videoElement.currentTime = targetTime;
    }

    // Drift never changes play/pause state — only nudges position.
    if (!isDrift) {
      if (data.action === 'play' && videoElement.paused) {
        videoElement.play().catch(() => showResumeHint());
      } else if (data.action === 'pause' && !videoElement.paused) {
        videoElement.pause();
      }
    }

    if (typeof data.rate === 'number' && data.rate > 0 && videoElement.playbackRate !== data.rate) {
      videoElement.playbackRate = data.rate;
    }
  } catch (err) {
    console.error('WatchTogether: applySyncState error', err);
  } finally {
    // Keep the 500ms echo-suppression window (the programmatic play/pause/seek above
    // fires events that must NOT be re-broadcast), but make it cancellable.
    if (syncResetTimer) clearTimeout(syncResetTimer);
    syncResetTimer = setTimeout(() => { isSyncing = false; syncResetTimer = null; }, 500);
  }
}

// Ask the server for the authoritative room position (used by Sync Now and when a
// lazy-loaded <video> first appears, so a late/Videasy joiner snaps to the group).
function requestSync() {
  if (ws && ws.readyState === WebSocket.OPEN && roomId) {
    ws.send(JSON.stringify({ type: 'request-sync', roomId }));
  }
}

// Sync Now (panel button): push MY current position to everyone as an authoritative
// seek. Re-detects a lazy-loaded video first so it works on any site (incl. Videasy).
function forceSync() {
  if (seekDebounceTimer) { clearTimeout(seekDebounceTimer); seekDebounceTimer = null; }
  if (!ws || ws.readyState !== WebSocket.OPEN || !roomId) {
    showNotification('Not connected to a room yet');
    return;
  }
  if (!videoElement) {
    const v = document.querySelector(VIDEO_SELECTORS[detectPlatform()] || 'video');
    if (v) { videoElement = v; setupVideoListeners(); }
  }
  if (!videoElement) {
    showNotification('Start playing the video first, then Sync Now');
    return;
  }
  sendSyncMessage({ type: 'seek', time: videoElement.currentTime, timestamp: Date.now() });
  lastSyncTime = Date.now();
  showNotification('Synced everyone to your position');
}

// Browsers can refuse programmatic play() (autoplay policy) — surface a one-click
// prompt instead of silently leaving this peer paused while others play.
function showResumeHint() {
  if (document.getElementById('wt-resume-hint')) return;
  const hint = document.createElement('div');
  hint.id = 'wt-resume-hint';
  hint.className = 'watchtogether-notification show';
  hint.style.cssText = 'cursor:pointer;';
  hint.textContent = '▶ Click to resume in sync';
  hint.addEventListener('click', () => {
    if (videoElement) videoElement.play().catch(() => {});
    hint.remove();
  });
  document.body.appendChild(hint);
  setTimeout(() => { if (hint.parentNode) hint.remove(); }, 8000);
}

// Send sync message. Only include `rate` for an actual ratechange so routine
// play/pause/seek messages can't accidentally reset everyone's playback speed.
function sendSyncMessage(data) {
  if (!ws || ws.readyState !== WebSocket.OPEN || !videoElement) return;

  const msg = {
    type: 'sync',
    roomId: roomId,
    username: username,
    action: data.type,
    time: data.time,
    paused: videoElement.paused,
    timestamp: data.timestamp
  };
  if (data.type === 'ratechange') msg.rate = videoElement.playbackRate;

  ws.send(JSON.stringify(msg));
}

// Start sync interval
function startSyncInterval() {
  if (syncInterval) return;

  syncInterval = setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'heartbeat',
        roomId: roomId,
        username: username,
        time: videoElement ? videoElement.currentTime : 0,
        paused: videoElement ? videoElement.paused : true,
        rate: videoElement ? videoElement.playbackRate : 1
      }));
    }
  }, SYNC_INTERVAL);

}

// Stop sync interval
function stopSyncInterval() {
  if (syncInterval) {
    clearInterval(syncInterval);
    syncInterval = null;
  }
}

// Setup message listener for popup
function setupMessageListener() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
      case 'CREATE_ROOM':
      case 'JOIN_ROOM': {
        // Fully tear down any previous session first so no old WebSocket, voice
        // stream, peer connection, timer, or on-screen chat leaks into the new room.
        resetSession();
        const isCreate = message.type === 'CREATE_ROOM';
        connectWebSocket(message.roomId, message.username, isCreate);
        showNotification(isCreate ? 'Room created! Share the room ID with friends.' : 'Joined room successfully!');
        showSidePanelWithLoading();
        resetPanelState();
        setTimeout(() => { hideSidePanelLoading(); }, 6000);
        sendResponse({ success: true });
        break;
      }

      case 'LEAVE_ROOM':
        leaveRoom(); // single teardown choke-point (also clears the minimized pill)
        sendResponse({ success: true });
        break;

      case 'CHAT_MESSAGE':
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'chat',
            roomId: roomId,
            username: message.username,
            message: message.message
          }));
        }
        sendResponse({ success: true });
        break;

      case 'FORCE_SYNC':
        forceSync();
        sendResponse({ success: true });
        break;

      case 'PING':
        sendResponse({
          success: true,
          hasVideo: !!videoElement,
          connected: ws && ws.readyState === WebSocket.OPEN,
          inRoom: !!roomId,
          roomId: roomId
        });
        break;
      
      case 'GET_PARTICIPANT_COUNT':
        // Request updated participant count from server
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'get_participants',
            roomId: roomId
          }));
        }
        sendResponse({ success: true });
        break;
      
      case 'TOGGLE_MIC':
        toggleMicrophone();
        sendResponse({ success: true, muted: isMuted });
        break;
    }

    return true;
  });
}

// Show notification on page
function showNotification(message) {
  const notification = document.createElement('div');
  notification.className = 'watchtogether-notification';
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => {
    notification.classList.add('show');
  }, 100);

  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 3000);
}

// Show side panel with loading overlay
function showSidePanelWithLoading() {
  showSidePanel();
  
  const panel = document.getElementById('watchtogether-panel');
  if (!panel) return;
  
  // Create loading overlay
  const loadingOverlay = document.createElement('div');
  loadingOverlay.id = 'wt-loading-overlay';
  loadingOverlay.innerHTML = `
    <div class="wt-loading-spinner"></div>
    <div class="wt-loading-text">Connecting...</div>
  `;
  panel.appendChild(loadingOverlay);
}

// Hide side panel loading
function hideSidePanelLoading() {
  const loadingOverlay = document.getElementById('wt-loading-overlay');
  if (loadingOverlay) {
    loadingOverlay.remove();
  }
}

// Notify popup
function notifyPopup(data) {
  chrome.runtime.sendMessage({
    type: 'BROADCAST_TO_POPUP',
    data: data
  }).catch(() => {
    // Popup might be closed
  });
}

// === VOICE CHAT FUNCTIONS ===

// Initialize voice chat. Epoch-guarded: if the session is torn down while
// getUserMedia is still pending, the resolved stream is discarded (and its mic
// released) instead of clobbering the new session / leaking a hot mic.
async function initVoiceChat() {
  const myEpoch = voiceEpoch;
  try {
    console.log('WatchTogether: Requesting microphone access...');
    getTurnCredentials().catch(() => {}); // warm in parallel

    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: false
    });

    if (myEpoch !== voiceEpoch) {
      // Session changed during the await — release this orphan mic and bail.
      stream.getTracks().forEach(t => t.stop());
      return;
    }

    console.log('WatchTogether: ✅ Microphone access granted');
    localStream = stream;

    // Start muted by default
    localStream.getAudioTracks().forEach(track => {
      track.enabled = false;
      track.onended = () => console.log('WatchTogether: local audio track ended');
    });
    isMuted = true;
    updateSidePanel('voice-status', { muted: isMuted });

    if (ws && ws.readyState === WebSocket.OPEN && roomId) {
      ws.send(JSON.stringify({ type: 'mic-status', roomId, muted: isMuted }));
    }

    setupPeerConnections();
    console.log('WatchTogether: Voice chat initialized');
  } catch (error) {
    if (myEpoch !== voiceEpoch) return; // torn down; the error is irrelevant
    console.error('WatchTogether: Failed to get microphone access', error);
    showPermissionError('mic');
  }
}

// Re-acquire the mic after the OS/another app killed the track (no page refresh
// needed). Repairs existing peer connections in place via replaceTrack. Preserves
// the caller's intended mute state — defaults to MUTED so re-acquisition never
// silently opens a hot mic.
async function reacquireMic(wantMuted = true) {
  const myEpoch = voiceEpoch;
  try {
    if (localStream) localStream.getTracks().forEach(t => t.stop());
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: false
    });
    if (myEpoch !== voiceEpoch) { stream.getTracks().forEach(t => t.stop()); return; }

    localStream = stream;
    isMuted = wantMuted;
    const newAudioTrack = localStream.getAudioTracks()[0];
    newAudioTrack.enabled = !isMuted;
    newAudioTrack.onended = () => console.log('WatchTogether: local audio track ended');

    // Patch the audio sender on every existing PC, then cover any peer that has no PC yet.
    peerConnections.forEach(pc => {
      if (pc.signalingState === 'closed') return;
      const s = pc.getSenders().find(x => x.track && x.track.kind === 'audio');
      if (s) s.replaceTrack(newAudioTrack).catch(e => console.warn('WatchTogether: audio replaceTrack failed', e));
    });
    setupPeerConnections();

    updateSidePanel('voice-status', { muted: isMuted });
    if (myUserId) updateMicIconState(myUserId, !isMuted);
    if (ws && ws.readyState === WebSocket.OPEN && roomId) {
      ws.send(JSON.stringify({ type: 'mic-status', roomId, muted: isMuted }));
    }
    console.log('WatchTogether: Mic re-acquired');
  } catch (error) {
    if (myEpoch !== voiceEpoch) return;
    console.error('WatchTogether: Mic re-acquire failed', error);
    showPermissionError('mic');
  }
}

// Toggle microphone
async function toggleMicrophone() {
  if (!localStream) { initVoiceChat(); return; }
  const wantMuted = !isMuted; // the user's intent for THIS click
  // If the track died (OS suspended / device grabbed by another app), re-acquire
  // it — honouring the intended mute state — instead of toggling a dead track.
  if (!isStreamAlive(localStream)) { await reacquireMic(wantMuted); return; }

  isMuted = wantMuted;
  console.log('WatchTogether: Toggling microphone to:', isMuted ? 'MUTED' : 'UNMUTED');

  // Mute is purely track.enabled — the audio sender already carries this track on
  // every PC, so no renegotiation is needed (the old replaceTrack(sender.track)
  // loop was a no-op and has been removed).
  localStream.getAudioTracks().forEach(track => { track.enabled = !isMuted; });

  updateSidePanel('voice-status', { muted: isMuted });
  if (myUserId) updateMicIconState(myUserId, !isMuted);

  if (ws && ws.readyState === WebSocket.OPEN && roomId) {
    ws.send(JSON.stringify({ type: 'mic-status', roomId, muted: isMuted }));
  }
}

// Setup peer connections with all participants
async function setupPeerConnections() {
  if (!localStream || !participants.length || !myUserId) {
    console.log('WatchTogether: Cannot setup connections - missing:', {
      hasLocalStream: !!localStream,
      participantsCount: participants.length,
      hasUserId: !!myUserId
    });
    return;
  }
  
  console.log('WatchTogether: Setting up peer connections. My ID:', myUserId);
  console.log('WatchTogether: Participants:', participants);
  
  for (const participant of participants) {
    // Don't create connection to self
    if (participant.userId === myUserId) continue;

    // Skip if a connection exists OR one is already being created (the await in
    // createPeerConnection yields, so without this guard two messages can race
    // and build duplicate PCs to the same peer).
    if (peerConnections.has(participant.userId) || creatingPeers.has(participant.userId)) continue;

    // Only initiate if our ID is "greater" to avoid both users initiating
    if (myUserId > participant.userId) {
      creatingPeers.add(participant.userId);
      try {
        await createPeerConnection(participant.userId, true);
      } finally {
        creatingPeers.delete(participant.userId);
      }
    }
    // else: we WAIT for the other side to initiate
  }
}

// Create WebRTC peer connection
async function createPeerConnection(userId, initiator = false) {
  console.log('WatchTogether: Creating peer connection to', userId, 'initiator:', initiator);

  const iceServers = await getTurnCredentials();
  const config = {
    iceServers,
    iceTransportPolicy: 'all',
    iceCandidatePoolSize: 10,
    bundlePolicy: 'max-bundle',
    rtcpMuxPolicy: 'require'
  };

  const pc = new RTCPeerConnection(config);

  // Add local audio track
  if (localStream) {
    localStream.getTracks().forEach(track => {
      pc.addTrack(track, localStream);
    });
    console.log('WatchTogether: Added', localStream.getTracks().length, 'track(s) to peer connection');
  } else {
    console.warn('WatchTogether: No localStream when creating peer connection');
  }

  // Add exactly ONE video track so ontrack fires on both sides from the start.
  // If our camera is already on (reconnect rebuild / late joiner), send the LIVE
  // track immediately — otherwise a silent placeholder we later replaceTrack().
  // (Adding both would create two video m-lines and break every video-sender lookup.)
  let outboundVideoTrack = null;
  if (isCameraOn && localVideoStream) outboundVideoTrack = localVideoStream.getVideoTracks()[0];
  const usingSilent = !outboundVideoTrack;
  if (usingSilent) outboundVideoTrack = createSilentVideoTrack();
  pc._silentVideoTrack = usingSilent ? outboundVideoTrack : null; // track for cleanup
  pc.addTrack(outboundVideoTrack, new MediaStream([outboundVideoTrack]));
  
  // Handle incoming tracks
  pc.ontrack = (event) => {
    console.log('WatchTogether: Received remote track from', userId, 'kind:', event.track.kind, '| muted:', event.track.muted);
    if (event.track.kind === 'audio') {
      playRemoteAudio(event.streams[0], userId);
    } else if (event.track.kind === 'video') {
      const stream = event.streams[0] || new MediaStream([event.track]);
      console.log('WatchTogether: ontrack video from', userId, '| muted:', event.track.muted);
      // Store stream — video-on WS message is the authority for showing the tile
      remoteVideoStreams.set(userId, stream);
      if (remoteCameraOn.get(userId) === true) {
        const p = participants.find(p => p.userId === userId);
        const name = p?.username || userId;
        updateVideoTile(userId, name, stream, false);
        waitForVideoData(userId, name);
      }
    }
  };
  
  // Handle connection state changes
  pc.onconnectionstatechange = () => {
    console.log('WatchTogether: Connection state with', userId, ':', pc.connectionState);
  };
  
  pc.oniceconnectionstatechange = () => {
    console.log('WatchTogether: ICE connection state with', userId, ':', pc.iceConnectionState);

    if (pc.iceConnectionState === 'failed') {
      console.log('WatchTogether: ICE failed, attempting restart...');
      restartIceConnection(userId, pc);
    } else if (pc.iceConnectionState === 'disconnected') {
      console.log('WatchTogether: ICE disconnected, monitoring for recovery...');
      setTimeout(() => {
        if (pc.iceConnectionState === 'disconnected') {
          console.log('WatchTogether: ICE still disconnected, attempting restart...');
          restartIceConnection(userId, pc);
        }
      }, 5000);
    }
  };
  
  // Handle ICE candidates
  pc.onicecandidate = (event) => {
    if (event.candidate) {
      console.log('WatchTogether: Generated ICE candidate:', event.candidate.type, event.candidate.protocol);
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'webrtc-ice-candidate',
          roomId: roomId,
          targetUserId: userId,
          candidate: event.candidate
        }));
      }
    } else {
      console.log('WatchTogether: ICE candidate gathering complete');
    }
  };
  
  // Store connection (close any prior PC for this user first to avoid leaks)
  const existing = peerConnections.get(userId);
  if (existing && existing !== pc) { try { existing.close(); } catch {} }
  peerConnections.set(userId, pc);

  // If initiator, create and send offer
  if (initiator) {
    pc.createOffer()
      .then(offer => pc.setLocalDescription(offer))
      .then(() => {
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'webrtc-offer',
            roomId: roomId,
            targetUserId: userId,
            offer: pc.localDescription
          }));
        }
      })
      .catch(err => console.error('WatchTogether: Error creating offer', err));
  }
  
  return pc;
}

// Re-signal an ICE restart. restartIce() alone only re-gathers locally — without
// a fresh offer the peer never learns, so the connection stays broken. Only the
// initiator side (higher userId) re-offers; the other side answers via the
// renegotiation branch below. This mirrors the initiator rule in setupPeerConnections.
async function restartIceConnection(userId, pc) {
  if (!(myUserId > userId)) return;
  if (pc.signalingState !== 'stable') return;
  try {
    const offer = await pc.createOffer({ iceRestart: true });
    await pc.setLocalDescription(offer);
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'webrtc-offer', roomId, targetUserId: userId, offer: pc.localDescription }));
    }
  } catch (e) {
    console.error('WatchTogether: ICE restart re-offer failed', e);
  }
}

// Drain ICE candidates that arrived before remoteDescription was set.
async function flushPendingCandidates(userId, pc) {
  const queued = pendingCandidates.get(userId);
  if (!queued || !queued.length) return;
  pendingCandidates.delete(userId);
  for (const c of queued) {
    try { await pc.addIceCandidate(new RTCIceCandidate(c)); }
    catch (e) { console.warn('WatchTogether: flush ICE candidate failed', e); }
  }
}

// Handle incoming WebRTC offer
async function handleWebRTCOffer(fromUserId, offer) {
  // Make sure we have a mic stream before building the connection (to send audio).
  if (!localStream) await initVoiceChat();
  if (!localStream) return; // init aborted (denied/torn down) — don't proceed with a null stream

  let pc = peerConnections.get(fromUserId);

  if (pc && (pc.connectionState === 'connected' || pc.connectionState === 'connecting')) {
    console.log('WatchTogether: Renegotiating existing connection from', fromUserId, '| signalingState:', pc.signalingState);
    try {
      if (pc.signalingState === 'have-local-offer') {
        // Glare: both sides offered at once — roll back and accept theirs.
        console.log('WatchTogether: Collision — rolling back local offer, accepting remote');
        await pc.setLocalDescription({ type: 'rollback' });
      }
      await pc.setRemoteDescription(new RTCSessionDescription(offer));
      await flushPendingCandidates(fromUserId, pc);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'webrtc-answer', roomId, targetUserId: fromUserId, answer: pc.localDescription }));
      }
    } catch (error) {
      console.error('WatchTogether: Error renegotiating offer', error);
    }
    return;
  }

  // No usable existing connection — drop a stale one and build fresh.
  if (pc) { try { pc.close(); } catch {} peerConnections.delete(fromUserId); }
  pc = await createPeerConnection(fromUserId, false);

  try {
    await pc.setRemoteDescription(new RTCSessionDescription(offer));
    await flushPendingCandidates(fromUserId, pc);
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'webrtc-answer', roomId, targetUserId: fromUserId, answer: pc.localDescription }));
    }
  } catch (error) {
    console.error('WatchTogether: Error handling offer', error);
  }
}

// Handle incoming WebRTC answer
async function handleWebRTCAnswer(fromUserId, answer) {
  const pc = peerConnections.get(fromUserId);
  if (!pc) return;
  try {
    await pc.setRemoteDescription(new RTCSessionDescription(answer));
    await flushPendingCandidates(fromUserId, pc);
    // ontrack may not fire for the answerer's video track — grab it from receivers directly
    const videoReceiver = pc.getReceivers().find(r => r.track?.kind === 'video');
    if (videoReceiver?.track && !remoteVideoStreams.has(fromUserId)) {
      remoteVideoStreams.set(fromUserId, new MediaStream([videoReceiver.track]));
      console.log('WatchTogether: stored video stream from answer receivers for', fromUserId);
    }
  } catch (error) {
    console.error('WatchTogether: Error handling answer', error);
  }
}

// Handle incoming ICE candidate. Buffer until remoteDescription exists — a
// candidate that arrives first would otherwise throw and the connection can
// stall in 'checking' (intermittent dead mic/video).
async function handleWebRTCIceCandidate(fromUserId, candidate) {
  const pc = peerConnections.get(fromUserId);
  if (!pc || !pc.remoteDescription || !pc.remoteDescription.type) {
    if (!pendingCandidates.has(fromUserId)) pendingCandidates.set(fromUserId, []);
    pendingCandidates.get(fromUserId).push(candidate);
    return;
  }
  try {
    await pc.addIceCandidate(new RTCIceCandidate(candidate));
  } catch (error) {
    console.error('WatchTogether: Error adding ICE candidate', error);
  }
}

// Play remote audio stream
function playRemoteAudio(stream, userId) {
  // Remove existing audio element if any
  const existingAudio = document.getElementById(`wt-audio-${userId}`);
  if (existingAudio) {
    existingAudio.remove();
  }
  
  // Create new audio element
  const audio = document.createElement('audio');
  audio.id = `wt-audio-${userId}`;
  audio.srcObject = stream;
  audio.autoplay = true;
  audio.volume = 1.0;
  audio.muted = false;
  audio.style.display = 'none';
  document.body.appendChild(audio);
  
  // Setup audio analysis for voice activity detection
  setupRemoteAudioAnalysis(stream, userId);
  
  // Monitor track state
  stream.getAudioTracks().forEach(track => {
    track.onended = () => {
      stopVoiceActivityDetection(userId);
      updateMicIconState(userId, false);
    };
    
    track.onmute = () => {
      updateVoiceIndicator(userId, false);
    };
  });
  
  // Force play in case autoplay is blocked
  audio.play()
    .then(() => {
      console.log('WatchTogether: Playing audio from', userId);
    })
    .catch(error => {
      console.error('WatchTogether: Error playing audio', error);
      setTimeout(() => audio.play().catch(() => {}), 100);
    });
}

// Setup audio analysis for remote user
function setupRemoteAudioAnalysis(stream, userId) {
  try {
    if (!audioContext) {
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
      console.log('WatchTogether: Created AudioContext, state:', audioContext.state);
    }
    
    // Resume if suspended
    if (audioContext.state === 'suspended') {
      audioContext.resume().then(() => {
        console.log('WatchTogether: AudioContext resumed');
      });
    }
    
    const source = audioContext.createMediaStreamSource(stream);
    const analyser = audioContext.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.8;
    
    // Connect to analyser for monitoring (doesn't affect audio playback)
    source.connect(analyser);
    
    // NOTE: We don't need to connect to destination - the audio element handles playback
    // The analyser is just for visualization
    
    // Store analyser
    remoteAnalysers.set(userId, analyser);
    
    // Start monitoring
    monitorVoiceActivity(userId, analyser);
    
    console.log('WatchTogether: Audio analysis setup for', userId);
  } catch (error) {
    console.error('WatchTogether: Error setting up audio analysis', error);
    // Don't let analysis errors break audio playback
  }
}

// Monitor voice activity
function monitorVoiceActivity(userId, analyser) {
  const dataArray = new Uint8Array(analyser.frequencyBinCount);
  const VOICE_THRESHOLD = 25; // Increased to filter out background noise (fan, etc.)
  const SILENCE_DURATION = 300; // ms - how long silence before hiding bars
  let lastSpeakingState = false;
  let lastSpeakTime = 0;
  let volumeHistory = [];
  const HISTORY_SIZE = 10;
  
  const checkActivity = () => {
    if (!remoteAnalysers.has(userId)) return; // Stop if analyser removed
    
    analyser.getByteFrequencyData(dataArray);
    
    // Calculate average volume (focus on speech frequencies 300Hz-3000Hz)
    let sum = 0;
    const speechRange = Math.floor(dataArray.length * 0.3); // Focus on lower frequencies (speech)
    for (let i = 0; i < speechRange; i++) {
      sum += dataArray[i];
    }
    const average = sum / speechRange;
    
    // Track volume history for variance calculation
    volumeHistory.push(average);
    if (volumeHistory.length > HISTORY_SIZE) {
      volumeHistory.shift();
    }
    
    // Calculate variance to detect sudden changes (voice) vs constant noise (fan)
    if (volumeHistory.length >= HISTORY_SIZE) {
      const mean = volumeHistory.reduce((a, b) => a + b) / volumeHistory.length;
      const variance = volumeHistory.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / volumeHistory.length;
      
      // Voice has higher variance than constant background noise
      const isVoicePattern = variance > 10 && average > VOICE_THRESHOLD;
      
      // Update voice indicator
      const now = Date.now();
      if (isVoicePattern) {
        lastSpeakTime = now;
        if (!lastSpeakingState) {
          console.log(`WatchTogether: Voice detected for ${userId} (volume: ${average.toFixed(1)}, variance: ${variance.toFixed(1)})`);
          lastSpeakingState = true;
          updateVoiceIndicator(userId, true);
        }
      } else if (lastSpeakingState && (now - lastSpeakTime) > SILENCE_DURATION) {
        console.log(`WatchTogether: Voice stopped for ${userId} (volume: ${average.toFixed(1)}, variance: ${variance.toFixed(1)})`);
        lastSpeakingState = false;
        updateVoiceIndicator(userId, false);
      }
    } else {
      // Not enough history yet, use simple threshold
      const isSpeaking = average > VOICE_THRESHOLD;
      if (isSpeaking !== lastSpeakingState) {
        lastSpeakingState = isSpeaking;
        updateVoiceIndicator(userId, isSpeaking);
      }
    }
    
    // Continue monitoring
    requestAnimationFrame(checkActivity);
  };
  
  checkActivity();
}

// Update voice indicator UI
function updateVoiceIndicator(userId, isSpeaking) {
  const voiceBars = document.getElementById(`voice-bars-${userId}`);
  
  if (voiceBars) {
    if (isSpeaking) {
      voiceBars.style.display = 'flex';
      voiceBars.classList.add('speaking');
    } else {
      voiceBars.classList.remove('speaking');
      setTimeout(() => {
        if (!voiceBars.classList.contains('speaking')) {
          voiceBars.style.display = 'none';
        }
      }, 300);
    }
  }
}

// Update mic icon state (muted/unmuted)
function updateMicIconState(userId, isEnabled) {
  const voiceIcon = document.getElementById(`voice-icon-${userId}`);
  if (!voiceIcon) return;
  if (isEnabled) {
    voiceIcon.classList.remove('muted');
    voiceIcon.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="11" rx="3"/><path d="M19 10a7 7 0 0 1-14 0"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>`;
  } else {
    voiceIcon.classList.add('muted');
    voiceIcon.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="2" y1="2" x2="22" y2="22"/><path d="M18.89 13.23A7.12 7.12 0 0 0 19 12"/><path d="M5 10a7 7 0 0 0 12.9 3.91"/><rect x="9" y="2" width="6" height="11" rx="3"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>`;
  }
}

// Handle incoming mic status update from other users
function handleMicStatusUpdate(userId, muted) {
  console.log(`WatchTogether: Received mic status from ${userId}: ${muted ? 'muted' : 'unmuted'}`);
  
  // Don't update our own icon - we handle that locally
  if (userId === myUserId) {
    return;
  }
  
  updateMicIconState(userId, !muted); // !muted because enabled = !muted
}

// Stop voice activity detection
function stopVoiceActivityDetection(userId) {
  if (remoteAnalysers.has(userId)) {
    remoteAnalysers.delete(userId);
  }
  updateVoiceIndicator(userId, false);
}

// Cleanup voice chat (also the single choke-point for resetting transient state).
function cleanupVoiceChat() {
  console.log('WatchTogether: Cleaning up voice chat...');

  // Invalidate any in-flight getUserMedia from this session so it can't clobber a new one.
  voiceEpoch++;

  if (localStream) {
    localStream.getTracks().forEach(track => track.stop());
    localStream = null;
  }

  peerConnections.forEach(pc => { stopSilentTracks(pc); try { pc.close(); } catch {} });
  peerConnections.clear();
  creatingPeers.clear();
  pendingCandidates.clear();

  // Remove all remote audio elements
  document.querySelectorAll('audio[id^="wt-audio-"]').forEach(audio => audio.remove());

  remoteAnalysers.clear();

  if (audioContext) {
    try { audioContext.close(); } catch {}
    audioContext = null;
  }

  // Reset per-session state
  resetSyncState();
  myUserId = null;
  isMuted = true;
  participants = [];
  remoteVideoStreams.clear();
  remoteCameraOn.clear();
  remoteMicMuted.clear();

  // Cleanup camera and clear all video tiles
  cleanupCamera();
  const tilesContainer = document.getElementById('wt-tiles-container');
  if (tilesContainer) tilesContainer.innerHTML = '';
}

let unreadCount = 0;
let isPanelMinimized = false;

// Inject side panel - Direct DOM injection
function injectSidePanel() {
  if (sidePanelInjected) return;

  // Inject CSS (guard by id so repeated re-injection after a host SPA wipes the
  // panel doesn't leak duplicate <style> tags).
  if (document.getElementById('wt-panel-style')) {
    // style already present from a prior injection — skip re-adding it
  } else {
  const style = document.createElement('style');
  style.id = 'wt-panel-style';
  style.textContent = `
    /* ── Design tokens ── */
    #watchtogether-panel, #wt-pill, #wt-reaction-layer {
      --wt-grad: linear-gradient(135deg,#6d7bff 0%,#a472ff 55%,#d06bff 100%);
      --wt-accent: #8b8bff;
      --wt-text: #f5f6fc;
      --wt-dim: #aab0c8;
      --wt-faint: #71768f;
      --wt-surface: rgba(255,255,255,0.045);
      --wt-surface-2: rgba(255,255,255,0.08);
      --wt-border: rgba(255,255,255,0.09);
      --wt-border-2: rgba(255,255,255,0.15);
      --wt-good: #34d399; --wt-bad: #fb7185; --wt-warn: #fbbf24;
    }
    #watchtogether-panel {
      position: fixed;
      top: 56px;
      right: 20px;
      width: 332px;
      height: auto;
      max-height: calc(100vh - 80px);
      min-height: 120px;
      background: rgba(18,19,28,0.72);
      -webkit-backdrop-filter: saturate(170%) blur(24px);
      backdrop-filter: saturate(170%) blur(24px);
      border: 1px solid var(--wt-border);
      border-radius: 20px;
      box-shadow: 0 24px 60px -16px rgba(0,0,0,0.65), 0 2px 8px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.06);
      z-index: 2147483646;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      color: var(--wt-text);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      transition: opacity .35s ease, transform .25s cubic-bezier(.34,1.56,.64,1);
    }
    .wt-accent-bar { height:3px; background:var(--wt-grad); flex-shrink:0; opacity:.9; }
    #watchtogether-panel.wt-hidden { display:none; }
    /* Header */
    .wt-panel-header {
      padding:12px 14px; border-bottom:1px solid var(--wt-border);
      display:flex; align-items:center; justify-content:space-between;
      cursor:move; flex-shrink:0; gap:8px;
    }
    .wt-panel-title { display:flex; align-items:center; gap:8px; font-size:13px; font-weight:700; letter-spacing:.2px; color:var(--wt-text); }
    .wt-panel-title svg { color:var(--wt-accent); }
    .wt-panel-controls { display:flex; gap:5px; align-items:center; }
    .wt-panel-btn {
      width:28px; height:28px; border:1px solid transparent; background:var(--wt-surface); color:var(--wt-dim);
      border-radius:9px; cursor:pointer; display:flex; align-items:center; justify-content:center;
      transition:all 0.16s ease; flex-shrink:0;
    }
    .wt-panel-btn:hover { background:var(--wt-surface-2); color:var(--wt-text); border-color:var(--wt-border-2); transform:translateY(-1px); }
    .wt-panel-btn:active { transform:translateY(0); }
    .wt-mic-btn { width:30px!important; height:30px!important; border-radius:50%!important; }
    .wt-mic-btn.muted { background:rgba(251,113,133,0.16)!important; color:var(--wt-bad)!important; border:1px solid rgba(251,113,133,0.32)!important; }
    .wt-mic-btn.active { background:rgba(52,211,153,0.16)!important; color:var(--wt-good)!important; border:1px solid rgba(52,211,153,0.34)!important; box-shadow:0 0 0 3px rgba(52,211,153,0.12); }
    /* Collapsible section headers */
    .wt-sec-header {
      padding:9px 14px; display:flex; align-items:center; justify-content:space-between;
      cursor:pointer; user-select:none; flex-shrink:0; transition:background 0.15s;
    }
    .wt-sec-header:hover { background:rgba(255,255,255,0.03); }
    .wt-sec-label {
      font-size:9.5px; color:var(--wt-faint); text-transform:uppercase; letter-spacing:0.8px;
      display:flex; align-items:center; gap:7px; font-weight:700;
    }
    .wt-sec-right { display:flex; align-items:center; gap:8px; }
    .wt-chevron { width:13px; height:13px; color:var(--wt-faint); transition:transform 0.25s ease; flex-shrink:0; }
    .wt-sec.collapsed .wt-chevron { transform:rotate(-90deg); }
    .wt-sec.collapsed .wt-sec-body { display:none; }
    .wt-sec { border-bottom:1px solid var(--wt-border); }
    /* Room ID section */
    .wt-room-sec { background:var(--wt-surface); }
    .wt-room-sec .wt-sec-header { border-bottom:1px solid var(--wt-border); }
    .wt-room-sec.collapsed .wt-sec-header { border-bottom:none; }
    .wt-room-body { padding:10px 14px 13px; display:flex; align-items:center; justify-content:space-between; }
    .wt-room-id-value { font-family:'SF Mono','Courier New',monospace; font-size:18px; font-weight:700; color:var(--wt-text); letter-spacing:3px; }
    .wt-copy-mini {
      display:flex; align-items:center; gap:5px; padding:6px 11px; background:var(--wt-surface-2);
      border:1px solid var(--wt-border); border-radius:8px; color:var(--wt-dim); font-size:10px;
      font-weight:600; cursor:pointer; font-family:inherit; transition:all 0.16s;
    }
    .wt-copy-mini:hover { border-color:var(--wt-accent); color:var(--wt-accent); background:rgba(139,139,255,0.12); }
    .wt-watching-pill { display:flex; align-items:center; gap:5px; font-size:10px; color:var(--wt-dim); }
    .wt-live-dot { width:6px; height:6px; border-radius:50%; background:var(--wt-good); box-shadow:0 0 7px rgba(52,211,153,0.7); animation:wtBreathe 2.4s ease-in-out infinite; }
    @keyframes wtBreathe{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.55;transform:scale(.82)}}
    /* Header sync chip */
    .wt-sync-chip {
      display:flex; align-items:center; gap:5px; padding:3px 9px 3px 7px; border-radius:20px;
      font-size:10px; font-weight:600; cursor:pointer; border:1px solid var(--wt-border);
      background:var(--wt-surface); color:var(--wt-dim); transition:all .16s; white-space:nowrap;
    }
    .wt-sync-chip:hover { border-color:var(--wt-border-2); }
    .wt-sync-chip .wt-sc-dot { width:6px; height:6px; border-radius:50%; background:var(--wt-faint); flex-shrink:0; }
    .wt-sync-chip.synced { color:var(--wt-good); border-color:rgba(52,211,153,0.3); background:rgba(52,211,153,0.1); }
    .wt-sync-chip.synced .wt-sc-dot { background:var(--wt-good); box-shadow:0 0 6px rgba(52,211,153,.7); }
    .wt-sync-chip.behind { color:var(--wt-warn); border-color:rgba(251,191,36,0.3); background:rgba(251,191,36,0.1); }
    .wt-sync-chip.behind .wt-sc-dot { background:var(--wt-warn); box-shadow:0 0 6px rgba(251,191,36,.7); }
    /* Participants section */
    .wt-parts-body { padding:7px 14px 9px; display:flex; flex-direction:column; gap:5px; }
    .wt-participant-item {
      display:flex; align-items:center; gap:9px; padding:6px 9px;
      background:var(--wt-surface); border:1px solid var(--wt-border); border-radius:10px; font-size:11.5px;
      transition:background .15s;
    }
    .wt-participant-item:hover { background:var(--wt-surface-2); }
    .wt-avatar {
      width:24px; height:24px; border-radius:50%; background:#6366f1;
      display:flex; align-items:center; justify-content:center;
      font-size:10px; font-weight:700; color:#fff; flex-shrink:0;
      box-shadow:0 2px 6px rgba(0,0,0,.25);
    }
    .wt-participant-name { flex:1; color:var(--wt-text); font-weight:500; }
    .wt-participant-mic { color:var(--wt-good); display:flex; align-items:center; }
    .wt-participant-mic.muted { color:var(--wt-bad); }
    .wt-voice-bars { display:flex; align-items:center; gap:2px; height:14px; margin-left:2px; }
    .wt-voice-bar { width:2px; background:var(--wt-good); border-radius:2px; }
    .wt-voice-bar:nth-child(1){height:4px} .wt-voice-bar:nth-child(2){height:8px} .wt-voice-bar:nth-child(3){height:12px}
    .wt-voice-bars.speaking .wt-voice-bar:nth-child(1){animation:wtBar1 0.5s ease-in-out infinite}
    .wt-voice-bars.speaking .wt-voice-bar:nth-child(2){animation:wtBar2 0.5s ease-in-out infinite 0.1s}
    .wt-voice-bars.speaking .wt-voice-bar:nth-child(3){animation:wtBar3 0.5s ease-in-out infinite 0.2s}
    @keyframes wtBar1{0%,100%{height:4px}50%{height:12px}}
    @keyframes wtBar2{0%,100%{height:8px}50%{height:14px}}
    @keyframes wtBar3{0%,100%{height:12px}50%{height:6px}}
    /* Video section */
    .wt-video-sec { background:rgba(0,0,0,0.18); }
    .wt-video-sec .wt-sec-header { border-bottom:1px solid var(--wt-border); }
    .wt-video-sec.collapsed .wt-sec-header { border-bottom:none; }
    .wt-video-body { padding:9px 14px 11px; }
    .wt-tiles-grid { display:grid; grid-template-columns:1fr 1fr; gap:6px; margin-bottom:4px; }
    .wt-tile {
      background:var(--wt-surface-2); border-radius:12px; aspect-ratio:16/9;
      display:flex; flex-direction:column; align-items:center; justify-content:center;
      gap:4px; position:relative; overflow:hidden; border:1px solid var(--wt-border);
    }
    .wt-tile.active { border-color:rgba(52,211,153,0.7); box-shadow:0 0 0 2px rgba(52,211,153,0.25); }
    .wt-tile video { position:absolute; inset:0; width:100%; height:100%; object-fit:cover; }
    .wt-tile-avatar {
      width:30px; height:30px; border-radius:50%;
      display:flex; align-items:center; justify-content:center;
      font-size:12px; font-weight:700; color:#fff; box-shadow:0 2px 8px rgba(0,0,0,.3);
    }
    .wt-tile-name {
      font-size:9.5px; color:#fff; font-weight:600;
      position:absolute; bottom:0; left:0; right:0; text-align:center;
      background:linear-gradient(to top,rgba(0,0,0,0.8),transparent); padding:8px 4px 4px;
    }
    .wt-cam-btn {
      display:flex; align-items:center; gap:5px; padding:4px 10px;
      border-radius:7px; border:1px solid var(--wt-border); background:var(--wt-surface-2);
      color:var(--wt-dim); font-size:10px; cursor:pointer; font-family:inherit; transition:all 0.16s;
    }
    .wt-cam-btn.on { background:rgba(52,211,153,0.16); color:var(--wt-good); border-color:rgba(52,211,153,0.4); }
    .wt-cam-btn.off { background:rgba(251,113,133,0.16); color:var(--wt-bad); border-color:rgba(251,113,133,0.4); }
    /* Reactions bar */
    .wt-reactions-bar {
      display:flex; align-items:center; gap:6px; padding:8px 14px; flex-shrink:0;
      border-bottom:1px solid var(--wt-border); justify-content:center;
    }
    .wt-react-btn {
      width:30px; height:30px; border-radius:50%; border:1px solid var(--wt-border);
      background:var(--wt-surface); font-size:15px; line-height:1; cursor:pointer;
      display:flex; align-items:center; justify-content:center; transition:transform .14s ease, background .14s;
      padding:0;
    }
    .wt-react-btn:hover { transform:translateY(-3px) scale(1.12); background:var(--wt-surface-2); }
    .wt-react-btn:active { transform:scale(.9); }
    /* Chat section */
    .wt-chat-sec { flex:1; display:flex; flex-direction:column; min-height:0; overflow:hidden; }
    .wt-chat-sec.collapsed { flex:0 0 auto; }
    .wt-chat-sec .wt-sec-header { border-bottom:1px solid var(--wt-border); }
    .wt-chat-sec.collapsed .wt-sec-header { border-bottom:none; }
    .wt-chat-sec .wt-sec-body { display:flex; flex-direction:column; flex:1; min-height:0; }
    .wt-unread-badge { background:var(--wt-grad); color:#fff; font-size:9px; font-weight:700; border-radius:10px; padding:1px 7px; }
    .wt-chat-container { flex:1 1 0; overflow-y:auto; overflow-x:hidden; padding:11px 14px; background:rgba(0,0,0,0.18); min-height:0; }
    .wt-chat-message { margin-bottom:9px; animation:wtSlideIn 0.25s ease; }
    @keyframes wtSlideIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
    .wt-chat-user { font-weight:700; font-size:12px; color:var(--wt-accent); margin-right:5px; }
    .wt-chat-time { font-size:9px; color:var(--wt-faint); margin-left:5px; font-weight:500; }
    .wt-chat-text { font-size:12.5px; color:#e6e8f2; line-height:1.45; word-wrap:break-word; }
    .wt-system-message { text-align:center; font-size:10px; color:var(--wt-faint); font-style:italic; margin:6px 0; }
    .wt-chat-input-area {
      padding:9px 12px; border-top:1px solid var(--wt-border);
      display:flex; gap:8px; flex-shrink:0;
    }
    .wt-chat-input {
      flex:1; padding:9px 13px; border:1px solid var(--wt-border); border-radius:10px;
      background:var(--wt-surface-2); color:var(--wt-text); font-size:12.5px; font-family:inherit; outline:none; transition:all 0.16s;
    }
    .wt-chat-input::placeholder { color:var(--wt-faint); }
    .wt-chat-input:focus { border-color:var(--wt-accent); box-shadow:0 0 0 3px rgba(139,139,255,0.14); }
    .wt-send-btn {
      padding:9px 13px; background:var(--wt-grad); color:#fff; border:none;
      border-radius:10px; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all 0.16s;
    }
    .wt-send-btn:hover { filter:brightness(1.12); transform:translateY(-1px); }
    .wt-send-btn:active { transform:translateY(0); }
    .wt-chat-container::-webkit-scrollbar{width:5px}
    .wt-chat-container::-webkit-scrollbar-track{background:transparent}
    .wt-chat-container::-webkit-scrollbar-thumb{background:var(--wt-border-2);border-radius:3px}
    /* Resize handle */
    .wt-resize-handle {
      text-align:center; padding:5px; font-size:8px; color:var(--wt-border-2);
      cursor:ns-resize; border-top:1px solid var(--wt-border);
      letter-spacing:3px; flex-shrink:0; user-select:none; transition:color .15s;
    }
    .wt-resize-handle:hover { color:var(--wt-dim); }
    /* Loading overlay */
    #wt-loading-overlay {
      position:absolute; inset:0; background:rgba(18,19,28,0.82);
      -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
      display:flex; flex-direction:column; align-items:center; justify-content:center;
      gap:13px; z-index:1000;
    }
    .wt-loading-spinner svg { animation:wtSpin 1s linear infinite; color:var(--wt-accent); }
    @keyframes wtSpin{to{transform:rotate(360deg)}}
    @keyframes wtPulse{0%,100%{opacity:1}50%{opacity:0.4}}
    .wt-loading-text { font-size:13px; font-weight:600; color:var(--wt-dim); animation:wtPulse 1.5s ease-in-out infinite; }
    /* Minimized pill */
    #wt-pill {
      position:fixed; bottom:24px; right:24px;
      display:none; align-items:center; gap:11px;
      padding:9px 15px 9px 11px;
      background:rgba(18,19,28,0.72);
      -webkit-backdrop-filter:saturate(170%) blur(22px); backdrop-filter:saturate(170%) blur(22px);
      border:1px solid var(--wt-border);
      border-radius:40px; box-shadow:0 14px 40px -10px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.06);
      z-index:2147483646; cursor:pointer; transition:all 0.2s;
    }
    #wt-pill.visible { display:flex; }
    #wt-pill:hover { border-color:var(--wt-border-2); box-shadow:0 16px 44px -10px rgba(124,124,255,0.35); transform:translateY(-2px); }
    .wt-pill-logo {
      width:32px; height:32px; background:var(--wt-grad);
      border-radius:50%; display:flex; align-items:center; justify-content:center; flex-shrink:0;
      box-shadow:0 4px 12px rgba(124,124,255,0.4);
    }
    .wt-pill-info { display:flex; flex-direction:column; gap:1px; }
    .wt-pill-name { font-size:12px; font-weight:700; color:var(--wt-text); }
    .wt-pill-status { font-size:10px; color:var(--wt-dim); display:flex; align-items:center; gap:5px; }
    .wt-pill-dot { width:6px; height:6px; border-radius:50%; background:var(--wt-good); box-shadow:0 0 6px rgba(52,211,153,0.7); }
    .wt-pill-divider { width:1px; height:22px; background:var(--wt-border-2); flex-shrink:0; }
    .wt-pill-mic {
      width:30px; height:30px; border-radius:50%; cursor:pointer; flex-shrink:0;
      display:flex; align-items:center; justify-content:center;
      background:rgba(251,113,133,0.16); color:var(--wt-bad); border:1px solid rgba(251,113,133,0.3);
    }
    .wt-pill-mic.on { background:rgba(52,211,153,0.16); color:var(--wt-good); border-color:rgba(52,211,153,0.3); }
    .wt-pill-expand {
      width:28px; height:28px; border-radius:50%; border:1px solid var(--wt-border);
      background:var(--wt-surface); color:var(--wt-dim); cursor:pointer; flex-shrink:0;
      display:flex; align-items:center; justify-content:center; transition:all 0.15s;
    }
    .wt-pill-expand:hover { border-color:var(--wt-accent); color:var(--wt-accent); }
    .wt-pill-unread {
      position:absolute; top:-6px; right:-6px;
      background:var(--wt-grad); color:#fff; font-size:10px; font-weight:700;
      border-radius:50%; width:20px; height:20px;
      display:flex; align-items:center; justify-content:center;
      border:2px solid #14151f;
      animation:wtPopIn 0.3s cubic-bezier(0.34,1.56,0.64,1);
    }
    @keyframes wtPopIn{from{transform:scale(0)}to{transform:scale(1)}}
    /* Leave confirm dialog */
    .wt-leave-dialog {
      position:absolute; inset:0; background:rgba(12,13,20,0.8);
      -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
      display:flex; flex-direction:column; align-items:center; justify-content:center;
      gap:12px; z-index:20; border-radius:20px;
    }
    .wt-leave-dialog-box {
      background:rgba(30,31,44,0.95); border:1px solid var(--wt-border-2); border-radius:16px;
      padding:22px 24px; text-align:center; display:flex; flex-direction:column;
      align-items:center; gap:14px; width:min(230px, calc(100% - 28px)); box-shadow:0 20px 50px -12px rgba(0,0,0,0.6);
    }
    .wt-leave-dialog-icon { color:var(--wt-bad); }
    .wt-leave-dialog-title { font-size:14px; font-weight:700; color:var(--wt-text); }
    .wt-leave-dialog-sub { font-size:11px; color:var(--wt-dim); line-height:1.5; }
    .wt-leave-dialog-btns { display:flex; gap:9px; width:100%; }
    .wt-leave-cancel {
      flex:1; padding:8px 0; border-radius:9px; border:1px solid var(--wt-border-2);
      background:var(--wt-surface); color:var(--wt-dim); font-size:12px; font-weight:600;
      cursor:pointer; font-family:inherit; transition:all 0.15s;
    }
    .wt-leave-cancel:hover { border-color:var(--wt-dim); color:var(--wt-text); }
    .wt-leave-confirm {
      flex:1; padding:8px 0; border-radius:9px; border:1px solid rgba(251,113,133,0.4);
      background:rgba(251,113,133,0.16); color:var(--wt-bad); font-size:12px; font-weight:600;
      cursor:pointer; font-family:inherit; transition:all 0.15s;
    }
    .wt-leave-confirm:hover { background:var(--wt-bad); color:#fff; border-color:var(--wt-bad); }
    /* Permission error */
    .wt-permission-error {
      position:absolute; inset:0; background:rgba(18,19,28,0.92);
      -webkit-backdrop-filter:blur(6px); backdrop-filter:blur(6px);
      display:flex; flex-direction:column; align-items:center; justify-content:center;
      gap:8px; padding:12px; text-align:center; z-index:10;
    }
    .wt-permission-error p { font-size:11px; color:var(--wt-dim); line-height:1.4; }
    .wt-permission-dismiss {
      font-size:10px; color:var(--wt-faint); background:none; border:none; cursor:pointer; font-family:inherit;
    }
    /* Attribution toast (inside panel, top) */
    .wt-attr-toast {
      position:absolute; top:46px; left:50%; transform:translateX(-50%) translateY(-8px);
      background:rgba(30,31,44,0.96); border:1px solid var(--wt-border-2); color:var(--wt-text);
      font-size:11px; font-weight:600; padding:6px 13px; border-radius:20px; white-space:nowrap;
      z-index:30; opacity:0; transition:opacity .25s, transform .25s; pointer-events:none;
      box-shadow:0 8px 24px -6px rgba(0,0,0,0.5);
    }
    .wt-attr-toast.show { opacity:1; transform:translateX(-50%) translateY(0); }
    /* Floating reaction layer (over the whole page) */
    #wt-reaction-layer {
      position:fixed; inset:0; pointer-events:none; z-index:2147483645; overflow:hidden;
    }
    .wt-react-float {
      position:absolute; font-size:34px; will-change:transform,opacity;
      animation:wtFloatUp 2.4s ease-out forwards; filter:drop-shadow(0 4px 10px rgba(0,0,0,0.4));
    }
    @keyframes wtFloatUp {
      0% { opacity:0; transform:translateY(0) scale(.4); }
      12% { opacity:1; transform:translateY(-14px) scale(1.15); }
      30% { transform:translateY(-60px) scale(1); }
      100% { opacity:0; transform:translateY(-230px) scale(.9); }
    }
    /* Cinema mode — slim, video-first dock; chrome hidden so the movie isn't blocked */
    #watchtogether-panel.wt-cinema .wt-room-sec,
    #watchtogether-panel.wt-cinema .wt-parts-sec,
    #watchtogether-panel.wt-cinema .wt-chat-sec,
    #watchtogether-panel.wt-cinema .wt-resize-handle,
    #watchtogether-panel.wt-cinema .wt-accent-bar { display:none; }
    #watchtogether-panel.wt-cinema { width:248px; height:auto!important; }
    /* Keep the video control row (cam + cinema-exit) but drop the label/chevron so
       there's always a way out of cinema and camera stays toggle-able. */
    #watchtogether-panel.wt-cinema .wt-video-sec .wt-sec-label,
    #watchtogether-panel.wt-cinema .wt-video-sec .wt-chevron { display:none; }
    #watchtogether-panel.wt-cinema .wt-video-sec .wt-sec-header { cursor:default; justify-content:flex-end; padding:8px 14px; }
    #watchtogether-panel.wt-cinema .wt-video-sec { background:transparent; border-bottom:none; }
    #watchtogether-panel.wt-cinema .wt-tiles-grid { grid-template-columns:1fr 1fr; }
    #watchtogether-panel.wt-cinema .wt-reactions-bar { border-bottom:none; padding-top:4px; }
    .wt-cinema-toggle.on { color:var(--wt-accent)!important; background:rgba(139,139,255,0.16)!important; border-color:rgba(139,139,255,0.4)!important; }
    /* Idle auto-dim (fullscreen) so the panel never hinders the movie */
    #watchtogether-panel.wt-idle { opacity:0.12; }
    #watchtogether-panel.wt-idle:hover { opacity:1; }
  `;
  document.head.appendChild(style);
  }

  // Create panel HTML
  const panel = document.createElement('div');
  panel.id = 'watchtogether-panel';
  panel.innerHTML = `
    <div class="wt-accent-bar"></div>
    <div class="wt-panel-header" id="wt-panel-header">
      <div class="wt-panel-title">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="color:var(--wt-accent)"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
        <div class="wt-sync-chip" id="wt-sync-chip" title="Sync status — click to catch up to the group">
          <span class="wt-sc-dot"></span><span id="wt-sync-chip-text">Sync</span>
        </div>
      </div>
      <div class="wt-panel-controls">
        <button class="wt-panel-btn" id="wt-sync-btn" title="Sync everyone to my position">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
        </button>
        <button class="wt-panel-btn wt-mic-btn muted" id="wt-mic-btn" title="Microphone (muted)">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="2" y1="2" x2="22" y2="22"/><path d="M18.89 13.23A7.12 7.12 0 0 0 19 12"/><path d="M5 10a7 7 0 0 0 12.9 3.91"/><rect x="9" y="2" width="6" height="11" rx="3"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>
        </button>
        <button class="wt-panel-btn" id="wt-minimize-btn" title="Minimise to pill">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>
        </button>
        <button class="wt-panel-btn" id="wt-close-btn" title="Hide">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
    </div>

    <!-- Room ID section -->
    <div class="wt-sec wt-room-sec collapsed" id="wt-room-sec">
      <div class="wt-sec-header" id="wt-room-sec-header">
        <div class="wt-sec-label">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          Room ID
        </div>
        <div class="wt-sec-right">
          <div class="wt-watching-pill"><div class="wt-live-dot"></div><span id="wt-panel-participants">0</span> watching</div>
          <svg class="wt-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
      </div>
      <div class="wt-sec-body wt-room-body">
        <div class="wt-room-id-value" id="wt-panel-room-id">------</div>
        <button class="wt-copy-mini" id="wt-copy-panel-btn">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
          Copy code
        </button>
      </div>
    </div>

    <!-- Participants section -->
    <div class="wt-sec wt-parts-sec collapsed" id="wt-parts-sec">
      <div class="wt-sec-header" id="wt-parts-sec-header">
        <div class="wt-sec-label">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          Participants
        </div>
        <div class="wt-sec-right">
          <span id="wt-parts-summary" style="font-size:10px;color:#94a3b8;"></span>
          <svg class="wt-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
      </div>
      <div class="wt-sec-body wt-parts-body" id="wt-participants-list"></div>
    </div>

    <!-- Video section -->
    <div class="wt-sec wt-video-sec" id="wt-video-sec">
      <div class="wt-sec-header" id="wt-video-sec-header">
        <div class="wt-sec-label">
          <div class="wt-live-dot"></div>
          Live Video
        </div>
        <div class="wt-sec-right">
          <button class="wt-panel-btn wt-cinema-toggle" id="wt-cinema-btn" title="Cinema mode — shrink to just video & mic" style="width:24px;height:24px;border-radius:7px;">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 7h20M2 17h20M7 3v18M17 3v18" opacity="0.5"/><rect x="2" y="3" width="20" height="18" rx="2"/></svg>
          </button>
          <button class="wt-cam-btn off" id="wt-cam-btn">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2"/><path d="M7.93 4H14a2 2 0 0 1 2 2v3.93"/><path d="M23 7l-7 5 7 5V7z"/><line x1="2" y1="2" x2="22" y2="22"/></svg>
            Cam off
          </button>
          <svg class="wt-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
      </div>
      <div class="wt-sec-body wt-video-body">
        <div class="wt-tiles-grid" id="wt-tiles-container"></div>
      </div>
    </div>

    <!-- Reactions bar -->
    <div class="wt-reactions-bar" id="wt-reactions-bar">
      <button class="wt-react-btn" data-emoji="❤️" title="React">❤️</button>
      <button class="wt-react-btn" data-emoji="😂" title="React">😂</button>
      <button class="wt-react-btn" data-emoji="😮" title="React">😮</button>
      <button class="wt-react-btn" data-emoji="🔥" title="React">🔥</button>
      <button class="wt-react-btn" data-emoji="👏" title="React">👏</button>
      <button class="wt-react-btn" data-emoji="😢" title="React">😢</button>
    </div>

    <!-- Chat section -->
    <div class="wt-sec wt-chat-sec" id="wt-chat-sec">
      <div class="wt-sec-header" id="wt-chat-sec-header">
        <div class="wt-sec-label">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
          Chat
          <span class="wt-unread-badge" id="wt-chat-unread" style="display:none">0</span>
        </div>
        <svg class="wt-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
      </div>
      <div class="wt-sec-body">
        <div class="wt-chat-container" id="wt-panel-chat">
          <div class="wt-system-message">Chat messages will appear here</div>
        </div>
        <div class="wt-chat-input-area">
          <input type="text" class="wt-chat-input" id="wt-panel-chat-input" placeholder="Type a message..." maxlength="200">
          <button class="wt-send-btn" id="wt-panel-send-btn">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>
      </div>
    </div>

    <div class="wt-resize-handle" id="wt-resize-handle">· · · · ·</div>
  `;

  document.body.appendChild(panel);

  // Minimized pill
  const pill = document.createElement('div');
  pill.id = 'wt-pill';
  pill.innerHTML = `
    <div class="wt-pill-logo">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
    </div>
    <div class="wt-pill-info">
      <div class="wt-pill-name">WatchTogether</div>
      <div class="wt-pill-status"><div class="wt-pill-dot"></div><span id="wt-pill-status">2 watching · ------</span></div>
    </div>
    <div class="wt-pill-divider"></div>
    <button class="wt-pill-mic muted" id="wt-pill-mic" title="Toggle mic">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="2" y1="2" x2="22" y2="22"/><path d="M18.89 13.23A7.12 7.12 0 0 0 19 12"/><path d="M5 10a7 7 0 0 0 12.9 3.91"/><rect x="9" y="2" width="6" height="11" rx="3"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>
    </button>
    <button class="wt-pill-expand" id="wt-pill-expand" title="Expand panel">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>
    </button>
  `;
  document.body.appendChild(pill);

  // Floating reaction overlay (covers the page; reparented in fullscreen too)
  if (!document.getElementById('wt-reaction-layer')) {
    const layer = document.createElement('div');
    layer.id = 'wt-reaction-layer';
    document.body.appendChild(layer);
  }

  // Setup event listeners
  setupPanelEventListeners();

  sidePanelInjected = true;
  console.log('WatchTogether: Side panel injected');
}

async function toggleCamera() {
  const camBtn = document.getElementById('wt-cam-btn');
  if (isCameraOn) {
    cleanupCamera();
    return;
  }
  // Only the getUserMedia call is permission-sensitive — keep it in its own try so a
  // later replaceTrack rejection isn't misreported as a camera-permission denial.
  let videoTrack;
  try {
    localVideoStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    videoTrack = localVideoStream.getVideoTracks()[0];
  } catch (err) {
    console.error('WatchTogether: Camera error', err);
    showPermissionError('camera');
    return;
  }

  isCameraOn = true;
  updateVideoTile(myUserId, username, localVideoStream, true);

  // replaceTrack on each PC's existing video sender (per-sender guarded so one
  // failure can't abort the rest or skip the UI/broadcast below).
  for (const [peerId, pc] of peerConnections) {
    if (pc.signalingState === 'closed') continue;
    const videoSender = pc.getSenders().find(s => s.track && s.track.kind === 'video');
    if (!videoSender) continue;
    const oldTrack = videoSender.track;
    try {
      await videoSender.replaceTrack(videoTrack);
      if (oldTrack && oldTrack._wtSilent) oldTrack.stop(); // free the placeholder pump
    } catch (e) { console.warn('WatchTogether: camera replaceTrack failed for', peerId, e); }
  }

  if (camBtn) {
    camBtn.classList.remove('off');
    camBtn.classList.add('on');
    camBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>`;
  }
  // Always announce once the camera is on (was previously skippable by a mid-loop throw).
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'video-on', roomId }));
  }
  applyCinemaMode();
}

async function cleanupCamera() {
  if (localVideoStream) {
    localVideoStream.getTracks().forEach(t => t.stop());
    localVideoStream = null;
  }
  // Replace with a silent track so the transceiver stays alive (next camera-on is
  // a cheap replaceTrack, no renegotiation). Per-sender guarded; each sender gets
  // its OWN silent track so stopping one peer's track never affects another.
  for (const [peerId, pc] of peerConnections) {
    if (pc.signalingState === 'closed') continue;
    const videoSender = pc.getSenders().find(s => s.track && s.track.kind === 'video');
    if (!videoSender) continue;
    try { await videoSender.replaceTrack(createSilentVideoTrack()); }
    catch (e) { console.warn('WatchTogether: silent replaceTrack failed for', peerId, e); }
  }
  isCameraOn = false;
  if (myUserId) updateVideoTile(myUserId, username, null, true);
  const camBtn = document.getElementById('wt-cam-btn');
  if (camBtn) {
    camBtn.classList.remove('on');
    camBtn.classList.add('off');
    camBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2"/><path d="M7.93 4H14a2 2 0 0 1 2 2v3.93"/><path d="M23 7l-7 5 7 5V7z"/><line x1="2" y1="2" x2="22" y2="22"/></svg>`;
  }
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'video-off', roomId }));
  }
  applyCinemaMode();
}

// Poll a tile's video element until it has actual frame data, then make it visible.
// Stops if camera turns off or tile is replaced.
function createSilentVideoTrack() {
  const canvas = document.createElement('canvas');
  canvas.width = 2; canvas.height = 2;
  canvas.getContext('2d').fillRect(0, 0, 2, 2);
  const stream = canvas.captureStream(1);
  const track = stream.getVideoTracks()[0];
  track._wtSilent = true; // marker so teardown can stop the 1fps capture pump
  return track;
}

// Stop any silent placeholder video tracks on a peer connection's senders (the
// canvas captureStream pump runs forever otherwise).
function stopSilentTracks(pc) {
  try {
    pc.getSenders().forEach(s => { if (s.track && s.track._wtSilent) s.track.stop(); });
  } catch {}
}

function waitForVideoData(userId, name) {
  const startStream = remoteVideoStreams.get(userId);
  const deadline = Date.now() + 10000;
  const poll = setInterval(() => {
    if (remoteCameraOn.get(userId) !== true || remoteVideoStreams.get(userId) !== startStream) {
      clearInterval(poll);
      return;
    }
    const tile = document.getElementById(`wt-tile-${userId}`);
    const vid = tile?.querySelector('video');
    if (!vid) { clearInterval(poll); return; }
    if (vid.readyState >= 2) {
      console.log('WatchTogether: video data ready for', userId);
      vid.style.opacity = '1';
      clearInterval(poll);
    } else if (Date.now() > deadline) {
      console.log('WatchTogether: video data wait timed out for', userId);
      clearInterval(poll);
    }
  }, 200);
}

const TILE_COLORS = ['#6366f1','#8b5cf6','#10b981','#f59e0b','#ef4444','#06b6d4'];

function updateVideoTile(userId, name, stream, isSelf) {
  const container = document.getElementById('wt-tiles-container');
  if (!container) return;

  const existingTile = document.getElementById(`wt-tile-${userId}`);
  const colorIdx = existingTile
    ? Array.from(container.children).indexOf(existingTile) % TILE_COLORS.length
    : container.children.length % TILE_COLORS.length;
  const initial = (name || '?')[0].toUpperCase();

  // Always replace the tile element entirely — this forces the compositor to
  // drop any GPU texture from a previous video element unconditionally.
  const newTile = document.createElement('div');
  newTile.id = `wt-tile-${userId}`;
  newTile.className = 'wt-tile';

  if (stream) {
    newTile.innerHTML = `
      <div class="wt-tile-avatar" style="background:${TILE_COLORS[colorIdx]}">${initial}</div>
      <div class="wt-tile-name">${name || ''}${isSelf ? ' (You)' : ''}</div>
    `;
    const vid = document.createElement('video');
    vid.autoplay = true;
    vid.muted = isSelf;
    vid.playsInline = true;
    vid.style.opacity = '0';
    vid.srcObject = stream;
    newTile.appendChild(vid);
    // Show on loadedmetadata, but also fall back via canplay and a timeout
    const revealVideo = () => { vid.style.opacity = '1'; };
    vid.addEventListener('loadedmetadata', revealVideo, { once: true });
    vid.addEventListener('canplay', revealVideo, { once: true });
    setTimeout(() => { if (vid.readyState >= 1) revealVideo(); }, 2000);
  } else {
    newTile.innerHTML = `
      <div class="wt-tile-avatar" style="background:${TILE_COLORS[colorIdx]}">${initial}</div>
      <div class="wt-tile-name">${name || ''}${isSelf ? ' (You)' : ''}</div>
    `;
  }

  if (existingTile) {
    // Tear down old video element completely before removing from DOM
    const oldVid = existingTile.querySelector('video');
    if (oldVid) {
      oldVid.pause();
      oldVid.srcObject = null;
      oldVid.load();
      oldVid.remove();
    }
    existingTile.replaceWith(newTile);
  } else {
    container.appendChild(newTile);
  }
}

function updateAllVideoTiles() {
  if (!sidePanelInjected) return;
  updateVideoTile(myUserId, username, isCameraOn ? localVideoStream : null, true);
  participants.forEach((p) => {
    if (p.userId === myUserId) return;
    const existingTile = document.getElementById(`wt-tile-${p.userId}`);
    if (!existingTile) {
      updateVideoTile(p.userId, p.username, null, false);
    }
  });
}

function showPermissionError(device) {
  const container = document.getElementById('wt-tiles-container');
  if (!container) return;
  const existing = container.querySelector('.wt-permission-error');
  if (existing) existing.remove();
  const err = document.createElement('div');
  err.className = 'wt-permission-error';
  err.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;padding:10px;text-align:center;color:#94a3b8;font-size:11px;';
  const isCamera = device === 'camera';
  err.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      ${isCamera
        ? '<path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2"/><path d="M7.93 4H14a2 2 0 0 1 2 2v3.93"/><path d="M23 7l-7 5 7 5V7z"/><line x1="2" y1="2" x2="22" y2="22"/>'
        : '<line x1="2" y1="2" x2="22" y2="22"/><path d="M18.89 13.23A7.12 7.12 0 0 0 19 12"/><path d="M5 10a7 7 0 0 0 12.9 3.91"/><rect x="9" y="2" width="6" height="11" rx="3"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/>'}
    </svg>
    <span>${isCamera ? 'Camera' : 'Microphone'} access denied.<br>Enable it in Chrome settings.</span>
    <button style="font-size:10px;color:#64748b;background:none;border:none;cursor:pointer;font-family:inherit;" onclick="this.closest('.wt-permission-error').remove()">Dismiss</button>
  `;
  container.appendChild(err);
  setTimeout(() => { if (err.parentNode) err.remove(); }, 8000);
}

// ── End Video Call ────────────────────────────────────────────────────────────

// Setup panel event listeners
function setupPanelEventListeners() {
  const panel = document.getElementById('watchtogether-panel');
  const header = document.getElementById('wt-panel-header');
  const minimizeBtn = document.getElementById('wt-minimize-btn');
  const closeBtn = document.getElementById('wt-close-btn');
  const chatInput = document.getElementById('wt-panel-chat-input');
  const sendBtn = document.getElementById('wt-panel-send-btn');
  const copyBtn = document.getElementById('wt-copy-panel-btn');
  const micBtn = document.getElementById('wt-mic-btn');
  const resizeHandle = document.getElementById('wt-resize-handle');
  const pill = document.getElementById('wt-pill');
  const pillMic = document.getElementById('wt-pill-mic');
  const pillExpand = document.getElementById('wt-pill-expand');

  // ── Drag panel ──
  let isDragging = false;
  let dragStartX, dragStartY, panelStartX, panelStartY;
  let panelX = 0, panelY = 0;

  header.addEventListener('mousedown', (e) => {
    if (e.target.closest('button')) return;
    isDragging = true;
    dragStartX = e.clientX; dragStartY = e.clientY;
    panelStartX = panelX; panelStartY = panelY;
    e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    panelX = panelStartX + (e.clientX - dragStartX);
    panelY = panelStartY + (e.clientY - dragStartY);
    panel.style.transform = `translate(${panelX}px, ${panelY}px)`;
  });
  document.addEventListener('mouseup', () => { isDragging = false; });

  // ── Resize panel height ──
  let isResizing = false;
  let resizeStartY, resizeStartH;
  resizeHandle.addEventListener('mousedown', (e) => {
    isResizing = true;
    resizeStartY = e.clientY;
    resizeStartH = panel.offsetHeight;
    e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => {
    if (!isResizing) return;
    const chatSec = document.getElementById('wt-chat-sec');
    if (chatSec && chatSec.classList.contains('collapsed')) return; // don't resize when chat collapsed
    const newH = Math.max(260, Math.min(window.innerHeight - 60, resizeStartH + (e.clientY - resizeStartY)));
    panel.style.height = newH + 'px';
  });
  document.addEventListener('mouseup', () => { isResizing = false; });

  // ── Collapsible sections ──
  const CHAT_EXPANDED_H = 520;
  const sections = [
    { secId: 'wt-room-sec', headerId: 'wt-room-sec-header' },
    { secId: 'wt-parts-sec', headerId: 'wt-parts-sec-header' },
    { secId: 'wt-video-sec', headerId: 'wt-video-sec-header' },
    { secId: 'wt-chat-sec', headerId: 'wt-chat-sec-header' },
  ];
  sections.forEach(({ secId, headerId }) => {
    const sec = document.getElementById(secId);
    const hdr = document.getElementById(headerId);
    hdr.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      sec.classList.toggle('collapsed');
      if (secId === 'wt-chat-sec') {
        if (sec.classList.contains('collapsed')) {
          panel.style.height = 'auto';
        } else {
          panel.style.height = CHAT_EXPANDED_H + 'px';
        }
      }
    });
  });
  // Set initial height since chat starts expanded
  panel.style.height = CHAT_EXPANDED_H + 'px';

  // ── Minimise → pill ──
  minimizeBtn.addEventListener('click', () => {
    isPanelMinimized = true;
    panel.classList.add('wt-hidden');
    pill.classList.add('visible');
    updatePillStatus();
  });

  // ── Close panel → leave room confirmation ──
  closeBtn.addEventListener('click', () => {
    showLeaveConfirm(panel);
  });

  // ── Pill expand → restore panel ──
  pillExpand.addEventListener('click', () => {
    isPanelMinimized = false;
    unreadCount = 0;
    panel.classList.remove('wt-hidden');
    pill.classList.remove('visible');
    updateChatUnreadBadge();
  });
  pill.addEventListener('click', (e) => {
    if (e.target.closest('#wt-pill-mic') || e.target.closest('#wt-pill-expand')) return;
    isPanelMinimized = false;
    unreadCount = 0;
    panel.classList.remove('wt-hidden');
    pill.classList.remove('visible');
    updateChatUnreadBadge();
  });

  // ── Pill mic button ──
  pillMic.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleMicrophone();
  });

  // ── Copy room ID ──
  copyBtn.addEventListener('click', () => {
    const roomIdEl = document.getElementById('wt-panel-room-id');
    navigator.clipboard.writeText(roomIdEl.textContent.trim());
    copyBtn.innerHTML = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Copied!`;
    setTimeout(() => {
      copyBtn.innerHTML = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copy code`;
    }, 2000);
  });

  // ── Camera toggle ──
  const camBtn = document.getElementById('wt-cam-btn');
  camBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleCamera();
  });

  // ── Chat send ──
  const sendMessage = () => {
    const message = chatInput.value.trim();
    if (!message) return;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'chat', roomId, username, message }));
    }
    chatInput.value = '';
  };
  sendBtn.addEventListener('click', sendMessage);
  chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); sendMessage(); }
  });

  // ── Mic toggle ──
  micBtn.addEventListener('click', toggleMicrophone);

  // ── Sync Now (force everyone to my position) ──
  const syncBtn = document.getElementById('wt-sync-btn');
  if (syncBtn) {
    syncBtn.addEventListener('click', () => {
      forceSync();
      // brief spin feedback
      syncBtn.style.transition = 'transform 0.5s';
      syncBtn.style.transform = 'rotate(360deg)';
      setTimeout(() => { syncBtn.style.transform = 'rotate(0deg)'; }, 500);
    });
  }

  // ── Sync status chip → click to catch up to the group ──
  const syncChip = document.getElementById('wt-sync-chip');
  if (syncChip) {
    syncChip.addEventListener('click', () => {
      requestSync();
      showNotification('Catching up to the group…');
    });
  }

  // ── Emoji reactions ──
  document.querySelectorAll('.wt-react-btn').forEach(btn => {
    btn.addEventListener('click', () => sendReaction(btn.dataset.emoji));
  });

  // ── Cinema mode toggle ──
  const cinemaBtn = document.getElementById('wt-cinema-btn');
  if (cinemaBtn) {
    cinemaBtn.addEventListener('click', (e) => { e.stopPropagation(); toggleCinemaMode(); });
  }
}

// ── Sync status chip ────────────────────────────────────────────────────────
// Updated from the server's periodic 'drift' broadcasts (authoritative time).
function updateSyncChip(targetTime, paused) {
  const chip = document.getElementById('wt-sync-chip');
  const text = document.getElementById('wt-sync-chip-text');
  if (!chip || !text) return;
  if (!videoElement || paused) {
    chip.className = 'wt-sync-chip';
    text.textContent = paused ? 'Paused' : 'Sync';
    return;
  }
  const diff = Math.abs(videoElement.currentTime - targetTime);
  if (diff <= SYNC_THRESHOLD) {
    chip.className = 'wt-sync-chip synced';
    text.textContent = 'In sync';
  } else {
    chip.className = 'wt-sync-chip behind';
    text.textContent = `${Math.round(diff)}s off`;
  }
}

// Reflect OUR OWN video state on the chip (our actions aren't echoed back to us).
function refreshSyncChipLocal() {
  if (videoElement) updateSyncChip(videoElement.currentTime, videoElement.paused);
}

// ── Emoji reactions ─────────────────────────────────────────────────────────
function sendReaction(emoji) {
  if (!emoji) return;
  spawnReaction(emoji); // show our own immediately
  if (ws && ws.readyState === WebSocket.OPEN && roomId) {
    ws.send(JSON.stringify({ type: 'reaction', roomId, emoji, username }));
  }
}

function spawnReaction(emoji) {
  const layer = document.getElementById('wt-reaction-layer');
  if (!layer) return;
  const el = document.createElement('div');
  el.className = 'wt-react-float';
  el.textContent = emoji;
  // Cluster near the bottom-right (over the panel side) with a little spread.
  const spread = 90;
  el.style.right = (40 + Math.random() * spread) + 'px';
  el.style.bottom = (90 + Math.random() * 40) + 'px';
  el.style.left = 'auto';
  layer.appendChild(el);
  setTimeout(() => el.remove(), 2500);
}

// ── Attribution toast ("Jayesh paused") ────────────────────────────────────
let attrToastTimer = null;
function showAttributionToast(message) {
  const panel = document.getElementById('watchtogether-panel');
  if (!panel) return;
  let toast = document.getElementById('wt-attr-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'wt-attr-toast';
    toast.className = 'wt-attr-toast';
    panel.appendChild(toast);
  }
  toast.textContent = message;
  // force reflow so the transition re-triggers
  void toast.offsetWidth;
  toast.classList.add('show');
  if (attrToastTimer) clearTimeout(attrToastTimer);
  attrToastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}

// ── Cinema mode ─────────────────────────────────────────────────────────────
// MANUAL ONLY — toggled by the cinema icon. It never auto-activates from a camera
// turning on. (The separate fullscreen idle auto-dim only changes opacity.)
let cinemaOn = false;
function applyCinemaMode() {
  const panel = document.getElementById('watchtogether-panel');
  const btn = document.getElementById('wt-cinema-btn');
  if (!panel) return;
  panel.classList.toggle('wt-cinema', cinemaOn);
  if (btn) {
    btn.classList.toggle('on', cinemaOn);
    btn.title = cinemaOn ? 'Exit cinema mode (expand panel)' : 'Cinema mode — shrink to just video & mic';
  }
}
function toggleCinemaMode() {
  cinemaOn = !cinemaOn;
  applyCinemaMode();
}

// Reset transient panel UI at the start of a new session (clear old chat, badges,
// minimized/pill state) so a previous room's content can't visually linger.
function resetPanelState() {
  isPanelMinimized = false;
  cinemaOn = false; // start expanded each session; cinema is opt-in via the icon
  unreadCount = 0;
  const pill = document.getElementById('wt-pill');
  if (pill) pill.classList.remove('visible');
  const panel = document.getElementById('watchtogether-panel');
  if (panel) panel.classList.remove('wt-hidden');
  const chat = document.getElementById('wt-panel-chat');
  if (chat) chat.innerHTML = '<div class="wt-system-message">Chat messages will appear here</div>';
  const partsList = document.getElementById('wt-participants-list');
  if (partsList) partsList.innerHTML = '';
  const tiles = document.getElementById('wt-tiles-container');
  if (tiles) tiles.innerHTML = '';
  updateChatUnreadBadge();
}

function showLeaveConfirm(panel) {
  if (document.getElementById('wt-leave-dialog')) return;
  const dialog = document.createElement('div');
  dialog.id = 'wt-leave-dialog';
  dialog.className = 'wt-leave-dialog';
  dialog.innerHTML = `
    <div class="wt-leave-dialog-box">
      <svg class="wt-leave-dialog-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      <div class="wt-leave-dialog-title">Leave room?</div>
      <div class="wt-leave-dialog-sub">You'll be disconnected from the session and video sync will stop.</div>
      <div class="wt-leave-dialog-btns">
        <button class="wt-leave-cancel" id="wt-leave-cancel">Cancel</button>
        <button class="wt-leave-confirm" id="wt-leave-confirm">Leave</button>
      </div>
    </div>
  `;
  // Temporarily expand out of Cinema mode so the dialog has room to render cleanly.
  const wasCinema = panel.classList.contains('wt-cinema');
  if (wasCinema) panel.classList.remove('wt-cinema');

  panel.appendChild(dialog);
  document.getElementById('wt-leave-cancel').addEventListener('click', () => {
    dialog.remove();
    if (wasCinema) applyCinemaMode(); // restore cinema if it was on
  });
  document.getElementById('wt-leave-confirm').addEventListener('click', () => {
    dialog.remove();
    leaveRoom();
  });
}

function leaveRoom() {
  resetSession(); // single teardown choke-point (sends leave, cancels timers, resets state)
  hideSidePanel();
  isPanelMinimized = false;
  const pill = document.getElementById('wt-pill');
  if (pill) pill.classList.remove('visible');
  chrome.storage.local.remove(['roomId']);
  // Tell the popup (if open) the session ended so it leaves the room view.
  notifyPopup({ type: 'CONNECTION_STATUS', connected: false });
  notifyPopup({ type: 'LEFT_ROOM' });
  showNotification('Left the room');
}

function updatePillStatus() {
  const pillStatus = document.getElementById('wt-pill-status');
  const countEl = document.getElementById('wt-panel-participants');
  if (pillStatus) {
    const count = countEl ? countEl.textContent : '0';
    const rid = roomId || '------';
    pillStatus.textContent = `${count} watching · ${rid}`;
  }
}

function updateChatUnreadBadge() {
  const badge = document.getElementById('wt-chat-unread');
  if (!badge) return;
  if (unreadCount > 0) {
    badge.textContent = unreadCount;
    badge.style.display = 'inline-block';
  } else {
    badge.style.display = 'none';
  }
  // Pill unread badge
  const pill = document.getElementById('wt-pill');
  if (!pill) return;
  let pillBadge = document.getElementById('wt-pill-unread');
  if (unreadCount > 0 && isPanelMinimized) {
    if (!pillBadge) {
      pillBadge = document.createElement('div');
      pillBadge.id = 'wt-pill-unread';
      pillBadge.className = 'wt-pill-unread';
      pill.appendChild(pillBadge);
    }
    pillBadge.textContent = unreadCount;
  } else if (pillBadge) {
    pillBadge.remove();
  }
}

// Update side panel
function updateSidePanel(type, data) {
  const panel = document.getElementById('watchtogether-panel');
  if (!panel) return;

  switch (type) {
    case 'chat':
      addPanelChatMessage(data.username, data.message);
      break;

    case 'system':
      addPanelChatMessage('', data.message, true);
      break;

    case 'room-info': {
      const roomIdEl = document.getElementById('wt-panel-room-id');
      const participantsEl = document.getElementById('wt-panel-participants');
      if (roomIdEl) roomIdEl.textContent = data.roomId || '------';
      if (participantsEl) participantsEl.textContent = data.participants || 0;
      updatePillStatus();
      break;
    }

    case 'show':
      panel.classList.remove('wt-hidden');
      break;

    case 'hide':
      panel.classList.add('wt-hidden');
      break;

    case 'voice-status': {
      const micBtn = document.getElementById('wt-mic-btn');
      const pillMic = document.getElementById('wt-pill-mic');
      const micMuted = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="2" y1="2" x2="22" y2="22"/><path d="M18.89 13.23A7.12 7.12 0 0 0 19 12"/><path d="M5 10a7 7 0 0 0 12.9 3.91"/><rect x="9" y="2" width="6" height="11" rx="3"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>`;
      const micOn = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="11" rx="3"/><path d="M19 10a7 7 0 0 1-14 0"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>`;
      if (micBtn) {
        micBtn.classList.toggle('muted', data.muted);
        micBtn.classList.toggle('active', !data.muted);
        micBtn.innerHTML = data.muted ? micMuted : micOn;
      }
      if (pillMic) {
        pillMic.classList.toggle('muted', data.muted);
        pillMic.classList.toggle('on', !data.muted);
        pillMic.innerHTML = data.muted ? micMuted : micOn;
      }
      break;
    }

    case 'participants-list':
      updateParticipantsList(data.participants);
      break;
  }
}

// Update participants list with voice indicators
function updateParticipantsList(participantsList) {
  const container = document.getElementById('wt-participants-list');
  if (!container) return;
  container.innerHTML = '';
  if (!participantsList || participantsList.length === 0) return;

  const colors = ['#6366f1','#8b5cf6','#10b981','#f59e0b','#ef4444','#06b6d4'];
  participantsList.forEach((participant, idx) => {
    const isSelf = participant.userId === myUserId;
    const color = colors[idx % colors.length];
    const initial = (participant.username || '?')[0].toUpperCase();
    const item = document.createElement('div');
    item.className = 'wt-participant-item';
    item.innerHTML = `
      <div class="wt-avatar" style="background:${color}">${initial}</div>
      <span class="wt-participant-name">${participant.username}${isSelf ? ' <span style="color:#64748b;font-size:10px;">(You)</span>' : ''}</span>
      <div class="wt-participant-mic muted" id="voice-icon-${participant.userId}">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="2" y1="2" x2="22" y2="22"/><path d="M18.89 13.23A7.12 7.12 0 0 0 19 12"/><path d="M5 10a7 7 0 0 0 12.9 3.91"/><rect x="9" y="2" width="6" height="11" rx="3"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>
      </div>
      <div class="wt-voice-bars" id="voice-bars-${participant.userId}" style="display:none">
        <div class="wt-voice-bar"></div><div class="wt-voice-bar"></div><div class="wt-voice-bar"></div>
      </div>
    `;
    container.appendChild(item);
    // Re-apply known mic state so a list rebuild doesn't reset icons to muted.
    if (isSelf) {
      if (localStream) updateMicIconState(participant.userId, !isMuted);
    } else if (remoteMicMuted.has(participant.userId)) {
      updateMicIconState(participant.userId, !remoteMicMuted.get(participant.userId));
    }
  });

  // Update collapsed summary
  const summary = document.getElementById('wt-parts-summary');
  if (summary) {
    summary.textContent = participantsList.map(p => p.username).join(', ');
  }
}

// Add chat message to panel
function addPanelChatMessage(username, message, isSystem = false) {
  const chatContainer = document.getElementById('wt-panel-chat');
  if (!chatContainer) return;

  const placeholder = chatContainer.querySelector('.wt-system-message');
  if (placeholder && placeholder.textContent === 'Chat messages will appear here') {
    chatContainer.innerHTML = '';
  }

  const messageEl = document.createElement('div');
  if (isSystem) {
    messageEl.className = 'wt-system-message';
    messageEl.textContent = message;
  } else {
    messageEl.className = 'wt-chat-message';
    const userSpan = document.createElement('span');
    userSpan.className = 'wt-chat-user';
    userSpan.textContent = username + ':';
    const textSpan = document.createElement('span');
    textSpan.className = 'wt-chat-text';
    textSpan.textContent = ' ' + message;
    messageEl.appendChild(userSpan);
    messageEl.appendChild(textSpan);
  }

  chatContainer.appendChild(messageEl);
  chatContainer.scrollTop = chatContainer.scrollHeight;

  // Unread tracking: count if chat section is collapsed or panel is minimized
  if (!isSystem) {
    const chatSec = document.getElementById('wt-chat-sec');
    const isCollapsed = chatSec && chatSec.classList.contains('collapsed');
    if (isPanelMinimized || isCollapsed) {
      unreadCount++;
      updateChatUnreadBadge();
    }
  }
}

// Show/hide side panel
function showSidePanel() {
  // Self-heal: if a host-page SPA tore the panel node out of the DOM, rebuild it.
  if (!sidePanelInjected || !document.getElementById('watchtogether-panel')) {
    sidePanelInjected = false;
    injectSidePanel();
  }
  updateSidePanel('show', {});
}

function hideSidePanel() {
  updateSidePanel('hide', {});
}

// ── Fullscreen panel persistence ──────────────────────────────────────────────
// When the browser fullscreens a child element (the video container), the panel
// (attached to <body>) falls behind the fullscreen layer.  We reparent the panel
// and pill into the fullscreen element so they stay on top.
let idleTimer = null;
function setupFullscreenHandler() {
  document.addEventListener('fullscreenchange', () => {
    const panel = document.getElementById('watchtogether-panel');
    const pill  = document.getElementById('wt-pill');
    const layer = document.getElementById('wt-reaction-layer');
    if (!panel) return;

    const fsEl = document.fullscreenElement;
    if (fsEl) {
      // Entering fullscreen — move panel, pill & reaction layer inside the fs root
      fsEl.appendChild(panel);
      if (pill) fsEl.appendChild(pill);
      if (layer) fsEl.appendChild(layer);
      panel.style.zIndex = '2147483647';
      if (pill) pill.style.zIndex = '2147483647';
      if (layer) layer.style.zIndex = '2147483647';
      startIdleWatch();
    } else {
      // Exiting fullscreen — restore to body and clear the auto-dim
      document.body.appendChild(panel);
      if (pill) document.body.appendChild(pill);
      if (layer) document.body.appendChild(layer);
      panel.style.zIndex = ''; if (pill) pill.style.zIndex = '';
      if (layer) layer.style.zIndex = '';
      stopIdleWatch();
      panel.classList.remove('wt-idle');
    }
    // Re-apply visibility after reparenting. Only restore the panel/pill when
    // there is an ACTIVE session — otherwise (e.g. the user left the room while
    // in fullscreen) keep both hidden so no empty panel is stranded on exit.
    if (roomId) {
      panel.classList.toggle('wt-hidden', isPanelMinimized);
      if (pill) pill.classList.toggle('visible', isPanelMinimized);
    } else {
      panel.classList.add('wt-hidden');
      if (pill) pill.classList.remove('visible');
    }
  });
}

// In fullscreen, fade the panel down after a few idle seconds so it never blocks
// the movie; any pointer movement brings it back instantly.
function onUserActivity() {
  const panel = document.getElementById('watchtogether-panel');
  if (!panel || !document.fullscreenElement) return;
  panel.classList.remove('wt-idle');
  if (idleTimer) clearTimeout(idleTimer);
  idleTimer = setTimeout(() => {
    if (document.fullscreenElement) panel.classList.add('wt-idle');
  }, 3500);
}
function startIdleWatch() {
  document.addEventListener('mousemove', onUserActivity, true);
  document.addEventListener('keydown', onUserActivity, true);
  onUserActivity();
}
function stopIdleWatch() {
  document.removeEventListener('mousemove', onUserActivity, true);
  document.removeEventListener('keydown', onUserActivity, true);
  if (idleTimer) { clearTimeout(idleTimer); idleTimer = null; }
}

// Initialize on load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => { init(); setupFullscreenHandler(); });
} else {
  init();
  setupFullscreenHandler();
}
