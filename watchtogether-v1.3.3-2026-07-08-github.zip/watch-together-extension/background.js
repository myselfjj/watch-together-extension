// Background service worker for WatchTogether extension

// Handle extension installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('WatchTogether extension installed');
});

// Handle messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_TAB_ID') {
    sendResponse({ tabId: sender.tab?.id });
  } else if (message.type === 'BROADCAST_TO_POPUP') {
    // Broadcast message to popup
    chrome.runtime.sendMessage(message.data).catch(() => {
      // Popup might be closed, ignore error
    });
  }
  return true;
});

// Keep service worker alive
chrome.runtime.onConnect.addListener((port) => {
  port.onDisconnect.addListener(() => {
    console.log('Port disconnected');
  });
});
